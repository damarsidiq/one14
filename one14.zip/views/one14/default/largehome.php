<body class="bgcarpet">
	<div id="translatorprof_a" class="">
		<a class="closemodal" id="closetrans_a" href="javascript:void(0);"></a>
			<p>
				Sir Abdullah Yusuf Ali, CBE, FRSL (14 April 1872 - 10 December 1953) was a British-Indian Islamic scholar who translated the Qur'an into English. His translation of the Qur'an is one of the most widely known and used in the English-speaking world. He was also one of the trustees of the East London Mosque.
			</p>
			<p>
				Ali was born in Bombay, British India to a wealthy merchant family with a Dawoodi Bohra (sub-sect of Shia Islam) father. As a child, Ali received a religious education and, eventually, could recite the entire Qur'an from memory. He spoke both Arabic and English fluently. He studied English literature and studied at several European universities, including the University of Leeds. He concentrated his efforts on the Qur'an and studied the Qur'anic commentaries beginning with those written in the early days of Islamic history.
			</p>
			<p>
				 Yusuf Ali's best-known work is his book The Holy Qur'an: Text, Translation and Commentary, begun in 1934 and published in 1938 by Sh. Muhammad Ashraf Publishers in Lahore, British India (that became Pakistan in 1947).
			</p>
			<p>
				While on tour to promote his translation, Ali helped to open the Al-Rashid Mosque, the third mosque in North America, in Edmonton, Alberta, Canada, in December 1938.
				Ali was an outspoken supporter of the Indian contribution to the Allied effort in World War I. He was a respected intellectual in India and Sir Muhammad Iqbal recruited him to be the principal of Islamia College in Lahore, British India. Later in life, he again went to England where he died in London. He is buried in England at the Muslim cemetery at Brookwood, Surrey, near Woking, not far from the burial place of Marmaduke Pickthall.
			</p>
	</div>
	<div id="translatorprof_m" class="">
		<a class="closemodal" id="closetrans_m" href="javascript:void(0);"></a>
		<p>
			Muhammad Quraish Shihab (Arabic: محمّد قريش شهاب‎; Muḥammad Qurayš Šihāb); February 16, 1944) is an Indonesian Muslim scholar in the sciences of the Qur'an, an author, a cleric, and former Minister of Religion Affairs in the Cabinet of Development VII (1998). He is the older brother of the former Coordinating Minister for People's Welfare, Alwi Shihab.
		</p>
		<p>
			Quraish was born in Rappang, on February 16, 1944. His father was Abdurrahman Shihab, an Islamic scholar and professor at State Institute of Islamic Sciences and his mother was Asma Aburisyi. Quraish is the fourth son of twelve siblings. His three older siblings, Nur, Ali and Umar, and two younger siblings, Wardah and Alwi Shihab, were also born in Rappang. Seven other siblings namely Nina, Sida, Nizar, Abdul Muthalib, Salwa and twin sister Ulfa and Latifah, were born in the village of Buton.
			Quraish Shihab is an Arab Indonesian of Ba'Alawi sada family, where his family lineage traces back to Muhammad, the prophet of Islam.
		</p>
		
		<p>
			After completing his early education in Ujung Pandang, Quraish continued his secondary education in Malang, which he did while at the Darul-Hadeeth Al-Faqihiyyah boarding school.
			In 1958 he went to Cairo, Egypt, and Admitted to 2nd grade in Al-Thanawiya at Al-Azhar. In 1967, he earned an LC (Bachelor degree) from the Department of Tafsir and Hadith, the faculty of Islamic Theology in Al-Azhar University. He continued his education at the same faculty in 1969 and earned Master degree in Tafseer of the Qur'an with the thesis entitled Al-I'jaz Tashri'i li Al-Qur-an Al-Karim.
			
		</p>
		<p>
			Upon returning to Makassar, Quraish served as the Vice Rector for Academic and Student Affairs at IAIN Alauddin, Ujung Pandang. In addition, he was also entrusted with other positions, both for academic positions such as the Coordinator of Private Higher Education Region VII in Eastern Indonesia, and non-academic positions such as the Assistant Police Chief of Eastern Indonesia in the field of mental development. While in Makassar, he also had time to do some researches. Some of his papers were "Implementation Harmony Religious Life in Eastern Indonesia" (1975) and "Problems Endowments South Sulawesi" (1978).
			In 1980, Quraish Shihab returned to Cairo and continued his education at his old alma mater. In 1982 He earned his doctorate in the sciences of the Qur'an with the dissertation studying the method of al-Biqa'i (al-Biqa'i is a scholar of exegesis from Damascus in the 15th century) entitled The Research and Study of The Pearls System of al-Biqa'i ( Arabic: نظم الدرر للبقاعي – تحقيق ودراسة, translit.: Naẓami Al-Durar li al-Biqā'iy - tahqīq wa Dirāsah), where he graduated Summa Cum Laude with first class honors (Arabic: ممتاز مع مرتبة الشرف العول, translit.: Mumtāz ma'a Martabat al-Sharaf al-'Ula).
		</p>

		<p>
			in 1984 Quraish was assigned as a lecturer in the Ushuluddin faculty and postgraduate faculty at IAIN Syarif Hidayatullah, Jakarta. He was entrusted to positions at various departments: among others; the co-chairman of Indonesian Ulema Council (MUI) (since 1984); member of Lajnah Pentashbih Qur'an at the Department of Religious Affairs (since 1989) and member of the Advisory Board of National Education (since 1989).
			Quraish Shihab is also heavily involved in several professional organizations; he is a member of the Shari'ah Science Society; member of the Consortium of the Religions at the Ministry of Education and Culture, and is the Assistant Chief of the General Association of Indonesian Muslim Intellectuals (ICMI).
			Quraish was appointed as Indonesian Minister of Religious Affairs in 1998 for about two months, and later appointed as The Indonesian Extraordinary and Plenipotentiary Ambassador to Egypt cum Djibouti in Cairo from 1999 to 2002.
		</p>

		<p>
			Quraish married to Fatmawati Assegaf on February 2, 1975 in Surakarta. From the marriage, they have four daughters (Najelaa, Najwa, Nasywa, Nahla) and one son (Ahmad).
		</p>
	</div>
	<div id="translatorprof_t" class="">
		<a class="closemodal" id="closetrans_t" href="javascript:void(0);"></a>
		<p>
			Tafsir al-Jalalayn ("Tafsir of the two Jalals") is a classical Sunni tafsir of the Qur'an, composed first by Jalal ad-Din al-Mahalli in 1459 and then completed by his student Jalal ad-Din as-Suyuti in 1505, thus its name, which means "Tafsir of the two Jalals".
		</p>
		<p> 
			It is recognised as one of the most popular exegeses of the Qur'an today, due to its simple style and its conciseness: It being only one volume in length. 
		</p>
		<p>
			An English translation by Aisha Bewley was published in 2007.
		</p>
	</div>
	<div id="thenames" class="carpet">
		<a class="closemodal" id="close99" href="javascript:void(0);"></a>
		<div id="thenamescontainer">
				<span class="oneof99"><span class="oneof99title" id="name_1">Ar-Rahmaan</span><span class="transoneof99">Maha pengasih</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_2">Ar-Rahiim</span><span class="transoneof99">Maha penyayang</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_3">As-Salaam</span><span class="transoneof99">Maha penyelamat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_4">Al-'Adl</span><span class="transoneof99">Maha adil</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_5">Al-Malik</span><span class="transoneof99">Maha merajai</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_6">Al-'Adzhiim</span><span class="transoneof99">Maha agung</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_7">Al-Jaliil</span><span class="transoneof99">Maha luhur</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_8">Al-'Aziiz</span><span class="transoneof99">Maha mulia/berkuasa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_9">Al-Ghafuur</span><span class="transoneof99">Maha pengampun</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_10">Al-Mu'min</span><span class="transoneof99">Maha pemelihara keamanan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_11">Al-Mutakabbir</span><span class="transoneof99">Maha megah/pelengkap kebesaran</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_12">Al-Baari'</span><span class="transoneof99">Maha pembuat/perancang</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_13">Al-Mushawwir</span><span class="transoneof99">Maha pembentuk</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_14">Al-Ghaffaar</span><span class="transoneof99">Maha pengampun, menutupi dosa dan kesalahan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_15">Al-Hafidz</span><span class="transoneof99">Maha pemelihara,pelindung dari kerusakan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_16">Al-Qahhaar</span><span class="transoneof99">Maha pemaksa dengan kehendaknya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_17">Al-Khaafidh</span><span class="transoneof99">Maha menjatuhkan/menghina/perendah</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_18">Al-Baasith</span><span class="transoneof99">Maha meluaskan/pelapang hidup/melimpah nikmat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_19">Al-Qaabidh</span><span class="transoneof99">Maha pencabut/penyempit hidup/mengambil nyawa/sempit rezeki</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_20">Al-Badii'</span><span class="transoneof99">Maha pencipta</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_21">Al-Awwal</span><span class="transoneof99">Maha permulaan,terdahulu dari semua yang maujud</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_22">Al-Aakhir</span><span class="transoneof99">Maha penghabisan/terakhir, kekal setelah habisnya segala yang maujud</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_23">Al-Raafi'</span><span class="transoneof99">Maha mengangkat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_24">Al-'Aliim</span><span class="transoneof99">Maha mengetahui</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_25">Al-Mu'iz</span><span class="transoneof99">Maha menghormati/ memuliakan, pemberi kemenangan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_26">Al-Muzil</span><span class="transoneof99">Maha menghina</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_27">As-Samii'</span><span class="transoneof99">Maha mendengar</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_28">Al-Bashiir</span><span class="transoneof99">Maha melihat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_29">Al-Jabbaar</span><span class="transoneof99">Maha perkasa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_30">Al-Hakam</span><span class="transoneof99">Maha mengadili</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_31">Al-Lathiif</span><span class="transoneof99">Maha menghalusi, teliti dan lembut</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_32">Al-Khabiir</span><span class="transoneof99">Maha waspada</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_33">Al-Muhaimin</span><span class="transoneof99">Maha pelindung/penjaga</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_34">Al-Quddus</span><span class="transoneof99">Maha suci, bersih dari segala cela dan kekurangan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_35">Al-Haliim</span><span class="transoneof99">Maha penyabar/penyantun/penghamba</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_36">Al-Wakiil</span><span class="transoneof99">Maha pentadbir/berserah, memelihara penyerahan urusan hamba-hambanya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_37">Al-Kabiir</span><span class="transoneof99">Maha besar, tidak dapat dicapai oleh pancaindera atau akal manusia</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_38">Al-Muqiit</span><span class="transoneof99">Maha pemberi kecukupan fisik ataupun rohani</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_39">Al-Khaaliq</span><span class="transoneof99">Maha pencipta</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_40">Al-Hay</span><span class="transoneof99">Maha hidup</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_41">Asy-Syakuur</span><span class="transoneof99">Maha pembalas/bersyukur</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_42">Al-Waasi'</span><span class="transoneof99">Maha luas pemberian-Nya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_43">Ar-Raqiib</span><span class="transoneof99">Maha peneliti dan waspada gerak-gerik segala sesuatu</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_44">Al-Mujiib</span><span class="transoneof99">Maha mengabulkan doa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_45">Al-Kariim</span><span class="transoneof99">Maha pemurah, memberi tanpa diminta ataupun penggantian</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_46">Al-Hakiim</span><span class="transoneof99">Maha bijaksana</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_47">Al-Majiid</span><span class="transoneof99">Maha mulia</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_48">Al-Waduud</span><span class="transoneof99">Maha pencinta/menyayangi</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_49">Asy-Syahiid</span><span class="transoneof99">Maha menyaksikan / mengetahui keadaan semua makhluk</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_50">Al-Ba'ithu</span><span class="transoneof99">Maha membangkitkan, semangat dan kemauan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_51">Ar-Razzaaq</span><span class="transoneof99">Maha pemberi rezeki beserta penyebab diperolehnya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_52">Al-'Aliy</span><span class="transoneof99">Maha tinggi</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_53">Al-Qawiy</span><span class="transoneof99">Maha kuat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_54">Al-Matiin</span><span class="transoneof99">Maha teguh/kukuh atau perkasa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_55">Al-Waliy</span><span class="transoneof99">Maha melindungi</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_56">Al-Hamiid</span><span class="transoneof99">Maha terpuji</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_57">Al-Muhshii</span><span class="transoneof99">Maha menghitung</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_58">Al-Muhyii</span><span class="transoneof99">Maha menghidupkan, memberikan daya kehidupan pada makhluknya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_59">Al-Mubdi'</span><span class="transoneof99">Maha memulai/pemula/pencipta dari asal yang tidak maujud</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_60">Al-Mu'iid</span><span class="transoneof99">Maha mengulangi/mengembalikan/memulihkan/menumbuhkan kembali setelah lenyap/rusak</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_61">Al-Ahad</span><span class="transoneof99">Maha tunggal</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_62">Al-Maajid</span><span class="transoneof99">Maha mulia</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_63">Al-Waahid</span><span class="transoneof99">Maha esa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_64">Al-Qayyum</span><span class="transoneof99">Maha berdiri dengan sendiri-Nya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_65">Al-Hasiib</span><span class="transoneof99">Maha penjamin/mencukupi/penghitung</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_66">Al-Mumiit</span><span class="transoneof99">Maha mematikan, mengambil roh dari segala yang hidup</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_67">Al-Waajid</span><span class="transoneof99">Maha penemu</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_68">Al-Qaadir</span><span class="transoneof99">Maha berkuasa/kuasa/berupaya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_69">Ash-Shamad</span><span class="transoneof99">Maha diperlukan/diminta/tumpuan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_70">Al-Muqtadir</span><span class="transoneof99">Maha menentukan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_71">Al-Muqaddim</span><span class="transoneof99">Maha mendahulukan/menyegera</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_72">Al-Muakhkhir</span><span class="transoneof99">Maha menangguhkan/ mengakhirkan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_73">Al-Haq</span><span class="transoneof99">Maha benar</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_74">Al-Wahhaab</span><span class="transoneof99">Maha pemberi</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_75">Al-Fattaah</span><span class="transoneof99">Maha membukakan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_76">Al-Waalii</span><span class="transoneof99">Maha menguasai semua urusan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_77">Al-Baathin</span><span class="transoneof99">Maha tersembunyi, tidak seorangpun mengenal ZatNya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_78">Al-Muta'aalii</span><span class="transoneof99">Maha suci/tinggi, terpelihara dari segala kekurangan dan kerendahan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_79">Al-Jaami'</span><span class="transoneof99">Maha mengumpulkan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_80">Al-Muqsith</span><span class="transoneof99">Maha mengadili</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_81">Zul-Jalaali Wal Ikraam</span><span class="transoneof99">Maha pemilik keagungan dan kemuliaan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_82">Maalikul Mulk</span><span class="transoneof99">Maha pemilik kekuasaan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_83">Ar-Rauuf</span><span class="transoneof99">Maha pengasih</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_84">Al-'Afuw</span><span class="transoneof99">Maha pemaaf/pengampun</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_85">Al-Bar</span><span class="transoneof99">Maha dermawan/bagus</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_86">At-Tawwaab</span><span class="transoneof99">Maha penerima taubat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_87">An-Naafi'</span><span class="transoneof99">Maha pemberi manfaat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_88">Al-Ghaniy</span><span class="transoneof99">Maha kaya raya dan serba lengkap</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_89">Al-Mughnii</span><span class="transoneof99">Maha pemberi kekayaan/memakmurkan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_90">Al-Maani'</span><span class="transoneof99">Maha membela, menolak, mencegah</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_91">Al-Muntaqim</span><span class="transoneof99">Maha penyiksa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_92">Adh-Dhaar</span><span class="transoneof99">Maha mendatangkan mudharat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_93">An-Nuur</span><span class="transoneof99">Maha pemberi cahaya/bercahaya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_94">Ash-Shabuur</span><span class="transoneof99">Maha penyabar</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_95">Azh-Zhaahir</span><span class="transoneof99">Maha nyata</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_96">Al-Baaqi</span><span class="transoneof99">Maha kekal</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_97">Al-Haadi</span><span class="transoneof99">Maha pemberi petunjuk</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_98">Al-Waarits</span><span class="transoneof99">Maha pembagi/ mewarisi/pewaris</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_99">Ar-Rasyiid</span><span class="transoneof99">Maha cendekiawan/pandai</span></span>
		</div>
	</div>
		
	</div>
		<div id="thei">
			    <a class="closemodal" id="closethei" href="javascript:void(0);"></a>
				<p><b>Onehundredandfourteen &copy 2015 Erwanto Damarsidiq</b></p>
				<p> <a href="mailto:damarsidiq@gmail.com">damarsidiq@gmail.com</a> - <a href="http://www.onluna.com" target="_blank">www.onluna.com</a></p>
				<p>Released under the MIT License: </p>
				<p id="licensedetail">
						Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the Software), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
						<br/><br/>The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
						<br/><br/><br/><br/>THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
				</p>
				
				<br/>
				<br/>

				<p>
					<ul class="lists">
						<li>Firefox is highly recommended to use this app</li>
						<li>Quran text provided by  <a href="http://www.tanzil.net" target="_blank">tanzil.net</a></li>
						<li>Quran recitation audio of Mishary Rashid Alafasy provided by <a href="http://www.versebyversequran.com" target="_blank">VerseByVerseQuran.Com</a> </li>
						<li>Hadith text provided by <a href="http://www.trendmuslim.com" target="_blank">HaditsWeb 6.0</a></li>
					</ul>
				</p>

				<br/>
				<br/>

				<p class="thankyou">
					thank you for using onehundredandfourteen
				</p>
				<p class="thankyou">
					 feel free to send any suggestion, feedback and comments
				</p>
		</div>
<div id="container">
    <div id="content">
        <div id="sura">
		 <h3 class="optdiv"></h3>
		 <div class="optdiv list">
			    <ul id="suralist">
				<?php echo $pagevar['suralist']; ?>
			    </ul>
		 </div>
            <div class="optdiv">
		<span class="multiinput">
			<h3>Start from</h3><h3>per page</h3>
		        <span><input type="number" value="1"  min="1" class="optinput" id="svnum"/></span>
		        <span><input type="number" value="5" max="5" min="1" class="optinput" id="vppnum"/></span>
			<span class="updatemultiinput"><input type="button" id="updateversesetting" value="GO" class="updatebutton"></span>
		</span>
            </div>
            <div class="optdiv">
                <h3>Translation</h3>
                <span id="arabic_opt" class="langopt"><input type="checkbox" id="arabic" class="optinput translang" checked="true" name="translang_arabic"><span class="transname">Arabic</span></span>
                <span id="english_opt" class="langopt"><input type="checkbox" id="english" class="optinput translang" checked="true" name="translang_english"><span class="transname">English</span><span class="infotrans" id="trans_a">i</span></span>
                <span id="indonesian_opt" class="langopt"><input type="checkbox" id="indonesian" class="optinput translang" name="translang_indonesian"><span class="transname">Indonesian</span></span>
                <span id="mqs_opt" class="langopt"><input type="checkbox" id="mqs" class="optinput translang" name="translang_mqs"><span class="transname">M. Quraish Shihab</span><span class="infotrans" id="trans_m">i</span></span>
                <span id="jalalayn_opt" class="langopt"><input type="checkbox" id="jalalayn" class="optinput translang" name="translang_jalalayn"><span class="transname">Tafsir Jalalayn</span><span class="infotrans" id="trans_t">i</span></span>
                <input type="button" id="updatetrans" value="update" class="updatebutton">
            </div>
            <div class="optdiv">
                <h3>Search</h3>
                <span><input type="text" id="searchkeyword" value="keyword"></span>
                <span>
                    <input type="radio" id="searchincurrent" name="searchins" checked="checked"><span class="searchscope">current sura</span>
                    <input type="radio" id="searchinall" name="searchins"><span class="searchscope">all sura</span>
                </span>
                <input type="button" id="getsearch" value="search" class="updatebutton">
            </div>
            <div class="optdiv">
                <h3>Audio</h3>
		<span class="multiinput">
			<h3 class="plain audiosett">Start</h3><h3 class="plain audiosett">End</h3>
		        <span class="audiosett clearleft"><input type="number" value="1" min="1" class="optinput" id="audiostart"/></span>
		        <span class="audiosett"><input type="number" value="7" min="1" class="optinput" id="audioend"/></span>
		        <span class="audiosett" id="loopaudio"></span>
			<span class="updatemultiinput audiosett"><input type="button" id="updateaudiodesc" value="play" class="updatebutton"></span>
			<audio src="" preload="true" id = "textaudio" mediagroup="quranaudio" controls="true" name="textaudio"></audio>
		</span>
            </div>
		<div id="about">&nbsp;i</div>
		<div id="bgselectcont">
			<div id="select_carpet" class="bgselect"></div>
			<div id="select_coral"    class="bgselect"></div>
			<div id="select_cloth"    class="bgselect"></div>
		</div>
		<div id="asmaulhusna">99</div>
        </div>

        <div id="verse">
            <div id="loadingnotif"></div>
            <div id="versecontainer">
                <ul id="verselist"></ul>
            </div>
            <div id="searchdesc" class=""><span id="searchdesctext"></span></div>
            <div id="prevaya" class="navi"></div>
            <div id="nextaya" class="navi"></div>
		<div id="viewswitch"></div>
        </div>
		
    </div>
	<div id="contenttwo">
		<div id="hadithcontent">
		    <div id="hadithloadingnotif"></div>
		    <div id="hadithcontainer">
			<div id="hadithmessage"><span>Select from the available options on the right</span></div>
			<ul id="hadithcontentlist"></ul>
		    </div>
		    <div id="hadithsearchdesc" class=""><span id="hadithsearchdesctext"></span></div>
		</div>



		<div id="hadith">
		    <div class="optdiv">
				<h3>Hadith</h3>
		        <span>
				    <input type="radio" id="Bukharibook_1" name="hadithchoose" checked="checked" class="choosehadith"><span class="searchscope">Bukhari</span>
				    <input type="radio" id="Muslimbook_2" name="hadithchoose" class="choosehadith"><span class="searchscope">Muslim</span>
				</span>
		    </div>
	           <h3 class="optdiv">Book</h3>
		    <div class="optdiv list">
				<ul id="hadithlist"></ul>
		    </div>
		<h3 class="optdiv hide" id="chapter">Chapter</h3>
	    	   <div class="optdiv list hide" id="chaptlistcont">
				<ul id="chaptlist">	</ul>
		    </div>
		    <div class="optdiv">
			<h3 id="searchhadithtext"><span class="plain">Search in</span> Bukhari</h3>
			<span><input type="text" id="searchhadith" value="keyword"></span>
			<span>
			    <input type="radio" id="searchincurrentimam" name="searchin" checked="checked"><span class="searchscope">in current book</span>
			    <input type="radio" id="searchinallimam" name="searchin"><span class="searchscope">in all book</span>
			</span>
			<input type="button" id="getsearchhadith" value="search" class="updatebutton">
		    </div>
		</div>

	</div>
</div>