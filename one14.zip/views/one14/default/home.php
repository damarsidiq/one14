	<div id="translatorprof_a" class="">
		<a class="closemodal" id="closetrans_a" href="javascript:void(0);"></a>
			<p>
				Sir Abdullah Yusuf Ali, CBE, FRSL (14 April 1872 - 10 December 1953) was a British-Indian Islamic scholar who translated the Qur'an into English. His translation of the Qur'an is one of the most widely known and used in the English-speaking world. He was also one of the trustees of the East London Mosque.
			</p>
			<p>
				Ali was born in Bombay, British India to a wealthy merchant family with a Dawoodi Bohra (sub-sect of Shia Islam) father. As a child, Ali received a religious education and, eventually, could recite the entire Qur'an from memory. He spoke both Arabic and English fluently. He studied English literature and studied at several European universities, including the University of Leeds. He concentrated his efforts on the Qur'an and studied the Qur'anic commentaries beginning with those written in the early days of Islamic history.
			</p>
			<p>
				 Yusuf Ali's best-known work is his book The Holy Qur'an: Text, Translation and Commentary, begun in 1934 and published in 1938 by Sh. Muhammad Ashraf Publishers in Lahore, British India (that became Pakistan in 1947).
			</p>
			<p>
				While on tour to promote his translation, Ali helped to open the Al-Rashid Mosque, the third mosque in North America, in Edmonton, Alberta, Canada, in December 1938.
				Ali was an outspoken supporter of the Indian contribution to the Allied effort in World War I. He was a respected intellectual in India and Sir Muhammad Iqbal recruited him to be the principal of Islamia College in Lahore, British India. Later in life, he again went to England where he died in London. He is buried in England at the Muslim cemetery at Brookwood, Surrey, near Woking, not far from the burial place of Marmaduke Pickthall.
			</p>
	</div>
	<div id="translatorprof_m" class="">
		<a class="closemodal" id="closetrans_m" href="javascript:void(0);"></a>
		<p>
			Muhammad Quraish Shihab (Arabic: محمّد قريش شهاب‎; Muḥammad Qurayš Šihāb); February 16, 1944) is an Indonesian Muslim scholar in the sciences of the Qur'an, an author, a cleric, and former Minister of Religion Affairs in the Cabinet of Development VII (1998). He is the older brother of the former Coordinating Minister for People's Welfare, Alwi Shihab.
		</p>
		<p>
			Quraish was born in Rappang, on February 16, 1944. His father was Abdurrahman Shihab, an Islamic scholar and professor at State Institute of Islamic Sciences and his mother was Asma Aburisyi. Quraish is the fourth son of twelve siblings. His three older siblings, Nur, Ali and Umar, and two younger siblings, Wardah and Alwi Shihab, were also born in Rappang. Seven other siblings namely Nina, Sida, Nizar, Abdul Muthalib, Salwa and twin sister Ulfa and Latifah, were born in the village of Buton.
			Quraish Shihab is an Arab Indonesian of Ba'Alawi sada family, where his family lineage traces back to Muhammad, the prophet of Islam.
		</p>
		
		<p>
			After completing his early education in Ujung Pandang, Quraish continued his secondary education in Malang, which he did while at the Darul-Hadeeth Al-Faqihiyyah boarding school.
			In 1958 he went to Cairo, Egypt, and Admitted to 2nd grade in Al-Thanawiya at Al-Azhar. In 1967, he earned an LC (Bachelor degree) from the Department of Tafsir and Hadith, the faculty of Islamic Theology in Al-Azhar University. He continued his education at the same faculty in 1969 and earned Master degree in Tafseer of the Qur'an with the thesis entitled Al-I'jaz Tashri'i li Al-Qur-an Al-Karim.
			
		</p>
		<p>
			Upon returning to Makassar, Quraish served as the Vice Rector for Academic and Student Affairs at IAIN Alauddin, Ujung Pandang. In addition, he was also entrusted with other positions, both for academic positions such as the Coordinator of Private Higher Education Region VII in Eastern Indonesia, and non-academic positions such as the Assistant Police Chief of Eastern Indonesia in the field of mental development. While in Makassar, he also had time to do some researches. Some of his papers were "Implementation Harmony Religious Life in Eastern Indonesia" (1975) and "Problems Endowments South Sulawesi" (1978).
			In 1980, Quraish Shihab returned to Cairo and continued his education at his old alma mater. In 1982 He earned his doctorate in the sciences of the Qur'an with the dissertation studying the method of al-Biqa'i (al-Biqa'i is a scholar of exegesis from Damascus in the 15th century) entitled The Research and Study of The Pearls System of al-Biqa'i ( Arabic: نظم الدرر للبقاعي – تحقيق ودراسة, translit.: Naẓami Al-Durar li al-Biqā'iy - tahqīq wa Dirāsah), where he graduated Summa Cum Laude with first class honors (Arabic: ممتاز مع مرتبة الشرف العول, translit.: Mumtāz ma'a Martabat al-Sharaf al-'Ula).
		</p>

		<p>
			in 1984 Quraish was assigned as a lecturer in the Ushuluddin faculty and postgraduate faculty at IAIN Syarif Hidayatullah, Jakarta. He was entrusted to positions at various departments: among others; the co-chairman of Indonesian Ulema Council (MUI) (since 1984); member of Lajnah Pentashbih Qur'an at the Department of Religious Affairs (since 1989) and member of the Advisory Board of National Education (since 1989).
			Quraish Shihab is also heavily involved in several professional organizations; he is a member of the Shari'ah Science Society; member of the Consortium of the Religions at the Ministry of Education and Culture, and is the Assistant Chief of the General Association of Indonesian Muslim Intellectuals (ICMI).
			Quraish was appointed as Indonesian Minister of Religious Affairs in 1998 for about two months, and later appointed as The Indonesian Extraordinary and Plenipotentiary Ambassador to Egypt cum Djibouti in Cairo from 1999 to 2002.
		</p>

		<p>
			Quraish married to Fatmawati Assegaf on February 2, 1975 in Surakarta. From the marriage, they have four daughters (Najelaa, Najwa, Nasywa, Nahla) and one son (Ahmad).
		</p>
	</div>
	<div id="translatorprof_t" class="">
		<a class="closemodal" id="closetrans_t" href="javascript:void(0);"></a>
		<p>
			Tafsir al-Jalalayn ("Tafsir of the two Jalals") is a classical Sunni tafsir of the Qur'an, composed first by Jalal ad-Din al-Mahalli in 1459 and then completed by his student Jalal ad-Din as-Suyuti in 1505, thus its name, which means "Tafsir of the two Jalals".
		</p>
		<p> 
			It is recognised as one of the most popular exegeses of the Qur'an today, due to its simple style and its conciseness: It being only one volume in length. 
		</p>
		<p>
			An English translation by Aisha Bewley was published in 2007.
		</p>
	</div>
	<div id="thenames" class="carpet">
		<a class="closemodal" id="close99" href="javascript:void(0);"></a>
		<div id="thenamescontainer">
				<span class="oneof99"><span class="oneof99title" id="name_1">Ar-Rahmaan</span><span class="transoneof99">Maha pengasih</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_2">Ar-Rahiim</span><span class="transoneof99">Maha penyayang</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_3">As-Salaam</span><span class="transoneof99">Maha penyelamat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_4">Al-'Adl</span><span class="transoneof99">Maha adil</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_5">Al-Malik</span><span class="transoneof99">Maha merajai</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_6">Al-'Adzhiim</span><span class="transoneof99">Maha agung</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_7">Al-Jaliil</span><span class="transoneof99">Maha luhur</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_8">Al-'Aziiz</span><span class="transoneof99">Maha mulia/berkuasa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_9">Al-Ghafuur</span><span class="transoneof99">Maha pengampun</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_10">Al-Mu'min</span><span class="transoneof99">Maha pemelihara keamanan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_11">Al-Mutakabbir</span><span class="transoneof99">Maha megah/pelengkap kebesaran</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_12">Al-Baari'</span><span class="transoneof99">Maha pembuat/perancang</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_13">Al-Mushawwir</span><span class="transoneof99">Maha pembentuk</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_14">Al-Ghaffaar</span><span class="transoneof99">Maha pengampun, menutupi dosa dan kesalahan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_15">Al-Hafidz</span><span class="transoneof99">Maha pemelihara,pelindung dari kerusakan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_16">Al-Qahhaar</span><span class="transoneof99">Maha pemaksa dengan kehendaknya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_17">Al-Khaafidh</span><span class="transoneof99">Maha menjatuhkan/menghina/perendah</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_18">Al-Baasith</span><span class="transoneof99">Maha meluaskan/pelapang hidup/melimpah nikmat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_19">Al-Qaabidh</span><span class="transoneof99">Maha pencabut/penyempit hidup/mengambil nyawa/sempit rezeki</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_20">Al-Badii'</span><span class="transoneof99">Maha pencipta</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_21">Al-Awwal</span><span class="transoneof99">Maha permulaan,terdahulu dari semua yang maujud</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_22">Al-Aakhir</span><span class="transoneof99">Maha penghabisan/terakhir, kekal setelah habisnya segala yang maujud</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_23">Al-Raafi'</span><span class="transoneof99">Maha mengangkat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_24">Al-'Aliim</span><span class="transoneof99">Maha mengetahui</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_25">Al-Mu'iz</span><span class="transoneof99">Maha menghormati/ memuliakan, pemberi kemenangan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_26">Al-Muzil</span><span class="transoneof99">Maha menghina</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_27">As-Samii'</span><span class="transoneof99">Maha mendengar</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_28">Al-Bashiir</span><span class="transoneof99">Maha melihat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_29">Al-Jabbaar</span><span class="transoneof99">Maha perkasa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_30">Al-Hakam</span><span class="transoneof99">Maha mengadili</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_31">Al-Lathiif</span><span class="transoneof99">Maha menghalusi, teliti dan lembut</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_32">Al-Khabiir</span><span class="transoneof99">Maha waspada</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_33">Al-Muhaimin</span><span class="transoneof99">Maha pelindung/penjaga</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_34">Al-Quddus</span><span class="transoneof99">Maha suci, bersih dari segala cela dan kekurangan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_35">Al-Haliim</span><span class="transoneof99">Maha penyabar/penyantun/penghamba</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_36">Al-Wakiil</span><span class="transoneof99">Maha pentadbir/berserah, memelihara penyerahan urusan hamba-hambanya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_37">Al-Kabiir</span><span class="transoneof99">Maha besar, tidak dapat dicapai oleh pancaindera atau akal manusia</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_38">Al-Muqiit</span><span class="transoneof99">Maha pemberi kecukupan fisik ataupun rohani</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_39">Al-Khaaliq</span><span class="transoneof99">Maha pencipta</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_40">Al-Hay</span><span class="transoneof99">Maha hidup</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_41">Asy-Syakuur</span><span class="transoneof99">Maha pembalas/bersyukur</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_42">Al-Waasi'</span><span class="transoneof99">Maha luas pemberian-Nya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_43">Ar-Raqiib</span><span class="transoneof99">Maha peneliti dan waspada gerak-gerik segala sesuatu</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_44">Al-Mujiib</span><span class="transoneof99">Maha mengabulkan doa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_45">Al-Kariim</span><span class="transoneof99">Maha pemurah, memberi tanpa diminta ataupun penggantian</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_46">Al-Hakiim</span><span class="transoneof99">Maha bijaksana</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_47">Al-Majiid</span><span class="transoneof99">Maha mulia</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_48">Al-Waduud</span><span class="transoneof99">Maha pencinta/menyayangi</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_49">Asy-Syahiid</span><span class="transoneof99">Maha menyaksikan / mengetahui keadaan semua makhluk</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_50">Al-Ba'ithu</span><span class="transoneof99">Maha membangkitkan, semangat dan kemauan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_51">Ar-Razzaaq</span><span class="transoneof99">Maha pemberi rezeki beserta penyebab diperolehnya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_52">Al-'Aliy</span><span class="transoneof99">Maha tinggi</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_53">Al-Qawiy</span><span class="transoneof99">Maha kuat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_54">Al-Matiin</span><span class="transoneof99">Maha teguh/kukuh atau perkasa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_55">Al-Waliy</span><span class="transoneof99">Maha melindungi</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_56">Al-Hamiid</span><span class="transoneof99">Maha terpuji</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_57">Al-Muhshii</span><span class="transoneof99">Maha menghitung</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_58">Al-Muhyii</span><span class="transoneof99">Maha menghidupkan, memberikan daya kehidupan pada makhluknya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_59">Al-Mubdi'</span><span class="transoneof99">Maha memulai/pemula/pencipta dari asal yang tidak maujud</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_60">Al-Mu'iid</span><span class="transoneof99">Maha mengulangi/mengembalikan/memulihkan/menumbuhkan kembali setelah lenyap/rusak</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_61">Al-Ahad</span><span class="transoneof99">Maha tunggal</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_62">Al-Maajid</span><span class="transoneof99">Maha mulia</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_63">Al-Waahid</span><span class="transoneof99">Maha esa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_64">Al-Qayyum</span><span class="transoneof99">Maha berdiri dengan sendiri-Nya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_65">Al-Hasiib</span><span class="transoneof99">Maha penjamin/mencukupi/penghitung</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_66">Al-Mumiit</span><span class="transoneof99">Maha mematikan, mengambil roh dari segala yang hidup</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_67">Al-Waajid</span><span class="transoneof99">Maha penemu</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_68">Al-Qaadir</span><span class="transoneof99">Maha berkuasa/kuasa/berupaya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_69">Ash-Shamad</span><span class="transoneof99">Maha diperlukan/diminta/tumpuan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_70">Al-Muqtadir</span><span class="transoneof99">Maha menentukan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_71">Al-Muqaddim</span><span class="transoneof99">Maha mendahulukan/menyegera</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_72">Al-Muakhkhir</span><span class="transoneof99">Maha menangguhkan/ mengakhirkan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_73">Al-Haq</span><span class="transoneof99">Maha benar</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_74">Al-Wahhaab</span><span class="transoneof99">Maha pemberi</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_75">Al-Fattaah</span><span class="transoneof99">Maha membukakan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_76">Al-Waalii</span><span class="transoneof99">Maha menguasai semua urusan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_77">Al-Baathin</span><span class="transoneof99">Maha tersembunyi, tidak seorangpun mengenal ZatNya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_78">Al-Muta'aalii</span><span class="transoneof99">Maha suci/tinggi, terpelihara dari segala kekurangan dan kerendahan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_79">Al-Jaami'</span><span class="transoneof99">Maha mengumpulkan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_80">Al-Muqsith</span><span class="transoneof99">Maha mengadili</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_81">Zul-Jalaali Wal Ikraam</span><span class="transoneof99">Maha pemilik keagungan dan kemuliaan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_82">Maalikul Mulk</span><span class="transoneof99">Maha pemilik kekuasaan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_83">Ar-Rauuf</span><span class="transoneof99">Maha pengasih</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_84">Al-'Afuw</span><span class="transoneof99">Maha pemaaf/pengampun</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_85">Al-Bar</span><span class="transoneof99">Maha dermawan/bagus</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_86">At-Tawwaab</span><span class="transoneof99">Maha penerima taubat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_87">An-Naafi'</span><span class="transoneof99">Maha pemberi manfaat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_88">Al-Ghaniy</span><span class="transoneof99">Maha kaya raya dan serba lengkap</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_89">Al-Mughnii</span><span class="transoneof99">Maha pemberi kekayaan/memakmurkan</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_90">Al-Maani'</span><span class="transoneof99">Maha membela, menolak, mencegah</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_91">Al-Muntaqim</span><span class="transoneof99">Maha penyiksa</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_92">Adh-Dhaar</span><span class="transoneof99">Maha mendatangkan mudharat</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_93">An-Nuur</span><span class="transoneof99">Maha pemberi cahaya/bercahaya</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_94">Ash-Shabuur</span><span class="transoneof99">Maha penyabar</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_95">Azh-Zhaahir</span><span class="transoneof99">Maha nyata</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_96">Al-Baaqi</span><span class="transoneof99">Maha kekal</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_97">Al-Haadi</span><span class="transoneof99">Maha pemberi petunjuk</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_98">Al-Waarits</span><span class="transoneof99">Maha pembagi/ mewarisi/pewaris</span></span>
				<span class="oneof99"><span class="oneof99title" id="name_99">Ar-Rasyiid</span><span class="transoneof99">Maha cendekiawan/pandai</span></span>
		</div>
	</div>
		
	</div>
	
		<div id="thei">
			    <a class="closemodal" id="closethei" href="javascript:void(0);"></a>
				<p><b>Onehundredandfourteen &copy 2015 Erwanto Damarsidiq</b></p>
				<p> <a href="mailto:damarsidiq@gmail.com">damarsidiq@gmail.com</a> - <a href="http://www.onluna.com" target="_blank">www.onluna.com</a></p>
				<p>Released under the MIT License: </p>
				<p id="licensedetail">
						Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the Software), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
						<br/><br/>The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
						<br/><br/><br/><br/>THE SOFTWARE IS PROVIDED AS IS, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
				</p>
				
				<br/>
				<br/>

				<p>
					<ul class="lists">
						<li>Firefox is highly recommended to use this app</li>
						<li>Quran text provided by  <a href="http://www.tanzil.net" target="_blank">tanzil.net</a></li>
						<li>Quran recitation audio of Mishary Rashid Alafasy provided by <a href="http://www.versebyversequran.com" target="_blank">VerseByVerseQuran.Com</a></li>
						<li>Hadith text provided by <a href="http://www.trendmuslim.com" target="_blank">HaditsWeb 6.0</a></li>
					</ul>
				</p>
				<br/>
				<br/>

				<p class="thankyou">
					thank you for using onehundredandfourteen
				</p>
				<p class="thankyou">
					 feel free to send any suggestion, feedback and comments
				</p>
		</div>
		
		
	<div id="container">
		<div id="settings" class="contentofcontent">
			<div class="table">
				<div class="tablecell">
					<div class="choosecontentsettings">
						<ul>
							<li id="ccs_sura"><div class="tableshow"><div class="tablecellshow">Sura</div></div></li>
							<li id="ccs_page"><div class="tableshow"><div class="tablecellshow">Page Setting</div></div></li>
							<li id="ccs_trans"><div class="tableshow"><div class="tablecellshow">Translations</div></div></li>
							<li id="ccs_search"><div class="tableshow"><div class="tablecellshow">Search</div></div></li>
							<li id="ccs_audio"><div class="tableshow"><div class="tablecellshow">Audio</div></div></li>
						</ul>
						<span id="ccs_cancel"><div class="tableshow"><div class="tablecellshow">Cancel</div></div></span>
					</div>
				</div>
			</div>
			
			<div class="contentofcontent" id="settingsofsura">
				<div id="suralistcontainer">
					<div id="suralistcontentcontainer">
						<ul id="suralist">
							<li class="suralistitem" id="suranum_1"><span class="surname">1.Al-Faatiha</span><span class="engname">&nbsp;(The Opening)</span><span class="numofverse">7</span></li><li class="suralistitem" id="suranum_2"><span class="surname">2.Al-Baqara</span><span class="engname">&nbsp;(The Cow)</span><span class="numofverse">286</span></li><li class="suralistitem" id="suranum_3"><span class="surname">3.Aali Imraan</span><span class="engname">&nbsp;(The Family of Imraan)</span><span class="numofverse">200</span></li><li class="suralistitem" id="suranum_4"><span class="surname">4.An-Nisaa</span><span class="engname">&nbsp;(The Women)</span><span class="numofverse">176</span></li><li class="suralistitem" id="suranum_5"><span class="surname">5.Al-Maaida</span><span class="engname">&nbsp;(The Table)</span><span class="numofverse">120</span></li><li class="suralistitem" id="suranum_6"><span class="surname">6.Al-An'aam</span><span class="engname">&nbsp;(The Cattle)</span><span class="numofverse">165</span></li><li class="suralistitem" id="suranum_7"><span class="surname">7.Al-A'raaf</span><span class="engname">&nbsp;(The Heights)</span><span class="numofverse">206</span></li><li class="suralistitem" id="suranum_8"><span class="surname">8.Al-Anfaal</span><span class="engname">&nbsp;(The Spoils of War)</span><span class="numofverse">75</span></li><li class="suralistitem" id="suranum_9"><span class="surname">9.At-Tawba</span><span class="engname">&nbsp;(The Repentance)</span><span class="numofverse">129</span></li><li class="suralistitem" id="suranum_10"><span class="surname">10.Yunus</span><span class="engname">&nbsp;(Jonas)</span><span class="numofverse">109</span></li><li class="suralistitem" id="suranum_11"><span class="surname">11.Hud</span><span class="engname">&nbsp;(Hud)</span><span class="numofverse">123</span></li><li class="suralistitem" id="suranum_12"><span class="surname">12.Yusuf</span><span class="engname">&nbsp;(Joseph)</span><span class="numofverse">111</span></li><li class="suralistitem" id="suranum_13"><span class="surname">13.Ar-Ra'd</span><span class="engname">&nbsp;(The Thunder)</span><span class="numofverse">43</span></li><li class="suralistitem" id="suranum_14"><span class="surname">14.Ibrahim</span><span class="engname">&nbsp;(Abraham)</span><span class="numofverse">52</span></li><li class="suralistitem" id="suranum_15"><span class="surname">15.Al-Hijr</span><span class="engname">&nbsp;(The Rock)</span><span class="numofverse">99</span></li><li class="suralistitem" id="suranum_16"><span class="surname">16.An-Nahl</span><span class="engname">&nbsp;(The Bee)</span><span class="numofverse">128</span></li><li class="suralistitem" id="suranum_17"><span class="surname">17.Al-Israa</span><span class="engname">&nbsp;(The Night Journey)</span><span class="numofverse">111</span></li><li class="suralistitem" id="suranum_18"><span class="surname">18.Al-Kahf</span><span class="engname">&nbsp;(The Cave)</span><span class="numofverse">110</span></li><li class="suralistitem" id="suranum_19"><span class="surname">19.Maryam</span><span class="engname">&nbsp;(Mary)</span><span class="numofverse">98</span></li><li class="suralistitem" id="suranum_20"><span class="surname">20.Taahaa</span><span class="engname">&nbsp;(Taahaa)</span><span class="numofverse">135</span></li><li class="suralistitem" id="suranum_21"><span class="surname">21.Al-Anbiyaa</span><span class="engname">&nbsp;(The Prophets)</span><span class="numofverse">112</span></li><li class="suralistitem" id="suranum_22"><span class="surname">22.Al-Hajj</span><span class="engname">&nbsp;(The Pilgrimage)</span><span class="numofverse">78</span></li><li class="suralistitem" id="suranum_23"><span class="surname">23.Al-Muminoon</span><span class="engname">&nbsp;(The Believers)</span><span class="numofverse">118</span></li><li class="suralistitem" id="suranum_24"><span class="surname">24.An-Noor</span><span class="engname">&nbsp;(The Light)</span><span class="numofverse">64</span></li><li class="suralistitem" id="suranum_25"><span class="surname">25.Al-Furqaan</span><span class="engname">&nbsp;(The Criterion)</span><span class="numofverse">77</span></li><li class="suralistitem" id="suranum_26"><span class="surname">26.Ash-Shu'araa</span><span class="engname">&nbsp;(The Poets)</span><span class="numofverse">227</span></li><li class="suralistitem" id="suranum_27"><span class="surname">27.An-Naml</span><span class="engname">&nbsp;(The Ant)</span><span class="numofverse">93</span></li><li class="suralistitem" id="suranum_28"><span class="surname">28.Al-Qasas</span><span class="engname">&nbsp;(The Stories)</span><span class="numofverse">88</span></li><li class="suralistitem" id="suranum_29"><span class="surname">29.Al-Ankaboot</span><span class="engname">&nbsp;(The Spider)</span><span class="numofverse">69</span></li><li class="suralistitem" id="suranum_30"><span class="surname">30.Ar-Room</span><span class="engname">&nbsp;(The Romans)</span><span class="numofverse">60</span></li><li class="suralistitem" id="suranum_31"><span class="surname">31.Luqman</span><span class="engname">&nbsp;(Luqman)</span><span class="numofverse">34</span></li><li class="suralistitem" id="suranum_32"><span class="surname">32.As-Sajda</span><span class="engname">&nbsp;(The Prostration)</span><span class="numofverse">30</span></li><li class="suralistitem" id="suranum_33"><span class="surname">33.Al-Ahzaab</span><span class="engname">&nbsp;(The Clans)</span><span class="numofverse">73</span></li><li class="suralistitem" id="suranum_34"><span class="surname">34.Saba</span><span class="engname">&nbsp;(Sheba)</span><span class="numofverse">54</span></li><li class="suralistitem" id="suranum_35"><span class="surname">35.Faatir</span><span class="engname">&nbsp;(The Originator)</span><span class="numofverse">45</span></li><li class="suralistitem" id="suranum_36"><span class="surname">36.Yaseen</span><span class="engname">&nbsp;(Yaseen)</span><span class="numofverse">83</span></li><li class="suralistitem" id="suranum_37"><span class="surname">37.As-Saaffaat</span><span class="engname">&nbsp;(Those drawn up in Ranks)</span><span class="numofverse">182</span></li><li class="suralistitem" id="suranum_38"><span class="surname">38.Saad</span><span class="engname">&nbsp;(The letter Saad)</span><span class="numofverse">88</span></li><li class="suralistitem" id="suranum_39"><span class="surname">39.Az-Zumar</span><span class="engname">&nbsp;(The Groups)</span><span class="numofverse">75</span></li><li class="suralistitem" id="suranum_40"><span class="surname">40.Ghaafir</span><span class="engname">&nbsp;(The Forgiver)</span><span class="numofverse">85</span></li><li class="suralistitem" id="suranum_41"><span class="surname">41.Fussilat</span><span class="engname">&nbsp;(Explained in detail)</span><span class="numofverse">54</span></li><li class="suralistitem" id="suranum_42"><span class="surname">42.Ash-Shura</span><span class="engname">&nbsp;(Consultation)</span><span class="numofverse">53</span></li><li class="suralistitem" id="suranum_43"><span class="surname">43.Az-Zukhruf</span><span class="engname">&nbsp;(Ornaments of gold)</span><span class="numofverse">89</span></li><li class="suralistitem" id="suranum_44"><span class="surname">44.Ad-Dukhaan</span><span class="engname">&nbsp;(The Smoke)</span><span class="numofverse">59</span></li><li class="suralistitem" id="suranum_45"><span class="surname">45.Al-Jaathiya</span><span class="engname">&nbsp;(Crouching)</span><span class="numofverse">37</span></li><li class="suralistitem" id="suranum_46"><span class="surname">46.Al-Ahqaf</span><span class="engname">&nbsp;(The Dunes)</span><span class="numofverse">35</span></li><li class="suralistitem" id="suranum_47"><span class="surname">47.Muhammad</span><span class="engname">&nbsp;(Muhammad)</span><span class="numofverse">38</span></li><li class="suralistitem" id="suranum_48"><span class="surname">48.Al-Fath</span><span class="engname">&nbsp;(The Victory)</span><span class="numofverse">29</span></li><li class="suralistitem" id="suranum_49"><span class="surname">49.Al-Hujuraat</span><span class="engname">&nbsp;(The Inner Apartments)</span><span class="numofverse">18</span></li><li class="suralistitem" id="suranum_50"><span class="surname">50.Qaaf</span><span class="engname">&nbsp;(The letter Qaaf)</span><span class="numofverse">45</span></li><li class="suralistitem" id="suranum_51"><span class="surname">51.Adh-Dhaariyat</span><span class="engname">&nbsp;(The Winnowing Winds)</span><span class="numofverse">60</span></li><li class="suralistitem" id="suranum_52"><span class="surname">52.At-Tur</span><span class="engname">&nbsp;(The Mount)</span><span class="numofverse">49</span></li><li class="suralistitem" id="suranum_53"><span class="surname">53.An-Najm</span><span class="engname">&nbsp;(The Star)</span><span class="numofverse">62</span></li><li class="suralistitem" id="suranum_54"><span class="surname">54.Al-Qamar</span><span class="engname">&nbsp;(The Moon)</span><span class="numofverse">55</span></li><li class="suralistitem" id="suranum_55"><span class="surname">55.Ar-Rahmaan</span><span class="engname">&nbsp;(The Beneficent)</span><span class="numofverse">78</span></li><li class="suralistitem" id="suranum_56"><span class="surname">56.Al-Waaqia</span><span class="engname">&nbsp;(The Inevitable)</span><span class="numofverse">96</span></li><li class="suralistitem" id="suranum_57"><span class="surname">57.Al-Hadid</span><span class="engname">&nbsp;(The Iron)</span><span class="numofverse">29</span></li><li class="suralistitem" id="suranum_58"><span class="surname">58.Al-Mujaadila</span><span class="engname">&nbsp;(The Pleading Woman)</span><span class="numofverse">22</span></li><li class="suralistitem" id="suranum_59"><span class="surname">59.Al-Hashr</span><span class="engname">&nbsp;(The Exile)</span><span class="numofverse">24</span></li><li class="suralistitem" id="suranum_60"><span class="surname">60.Al-Mumtahana</span><span class="engname">&nbsp;(She that is to be examined)</span><span class="numofverse">13</span></li><li class="suralistitem" id="suranum_61"><span class="surname">61.As-Saff</span><span class="engname">&nbsp;(The Ranks)</span><span class="numofverse">14</span></li><li class="suralistitem" id="suranum_62"><span class="surname">62.Al-Jumu'a</span><span class="engname">&nbsp;(Friday)</span><span class="numofverse">11</span></li><li class="suralistitem" id="suranum_63"><span class="surname">63.Al-Munaafiqoon</span><span class="engname">&nbsp;(The Hypocrites)</span><span class="numofverse">11</span></li><li class="suralistitem" id="suranum_64"><span class="surname">64.At-Taghaabun</span><span class="engname">&nbsp;(Mutual Disillusion)</span><span class="numofverse">18</span></li><li class="suralistitem" id="suranum_65"><span class="surname">65.At-Talaaq</span><span class="engname">&nbsp;(Divorce)</span><span class="numofverse">12</span></li><li class="suralistitem" id="suranum_66"><span class="surname">66.At-Tahrim</span><span class="engname">&nbsp;(The Prohibition)</span><span class="numofverse">12</span></li><li class="suralistitem" id="suranum_67"><span class="surname">67.Al-Mulk</span><span class="engname">&nbsp;(The Sovereignty)</span><span class="numofverse">30</span></li><li class="suralistitem" id="suranum_68"><span class="surname">68.Al-Qalam</span><span class="engname">&nbsp;(The Pen)</span><span class="numofverse">52</span></li><li class="suralistitem" id="suranum_69"><span class="surname">69.Al-Haaqqa</span><span class="engname">&nbsp;(The Reality)</span><span class="numofverse">52</span></li><li class="suralistitem" id="suranum_70"><span class="surname">70.Al-Ma'aarij</span><span class="engname">&nbsp;(The Ascending Stairways)</span><span class="numofverse">44</span></li><li class="suralistitem" id="suranum_71"><span class="surname">71.Nooh</span><span class="engname">&nbsp;(Nooh)</span><span class="numofverse">28</span></li><li class="suralistitem" id="suranum_72"><span class="surname">72.Al-Jinn</span><span class="engname">&nbsp;(the Jinn)</span><span class="numofverse">28</span></li><li class="suralistitem" id="suranum_73"><span class="surname">73.Al-Muzzammil</span><span class="engname">&nbsp;(The Enshrouded One)</span><span class="numofverse">20</span></li><li class="suralistitem" id="suranum_74"><span class="surname">74.Al-Muddaththir</span><span class="engname">&nbsp;(The Cloaked One)</span><span class="numofverse">56</span></li><li class="suralistitem" id="suranum_75"><span class="surname">75.Al-Qiyaama</span><span class="engname">&nbsp;(The Resurrection)</span><span class="numofverse">40</span></li><li class="suralistitem" id="suranum_76"><span class="surname">76.Al-Insaan</span><span class="engname">&nbsp;(Man)</span><span class="numofverse">31</span></li><li class="suralistitem" id="suranum_77"><span class="surname">77.Al-Mursalaat</span><span class="engname">&nbsp;(The Emissaries)</span><span class="numofverse">50</span></li><li class="suralistitem" id="suranum_78"><span class="surname">78.An-Naba</span><span class="engname">&nbsp;(The Announcement)</span><span class="numofverse">40</span></li><li class="suralistitem" id="suranum_79"><span class="surname">79.An-Naazi'aat</span><span class="engname">&nbsp;(Those who drag forth)</span><span class="numofverse">46</span></li><li class="suralistitem" id="suranum_80"><span class="surname">80.Abasa</span><span class="engname">&nbsp;(He frowned)</span><span class="numofverse">42</span></li><li class="suralistitem" id="suranum_81"><span class="surname">81.At-Takwir</span><span class="engname">&nbsp;(The Overthrowing)</span><span class="numofverse">29</span></li><li class="suralistitem" id="suranum_82"><span class="surname">82.Al-Infitaar</span><span class="engname">&nbsp;(The Cleaving)</span><span class="numofverse">19</span></li><li class="suralistitem" id="suranum_83"><span class="surname">83.Al-Mutaffifin</span><span class="engname">&nbsp;(Defrauding)</span><span class="numofverse">36</span></li><li class="suralistitem" id="suranum_84"><span class="surname">84.Al-Inshiqaaq</span><span class="engname">&nbsp;(The Splitting Open)</span><span class="numofverse">25</span></li><li class="suralistitem" id="suranum_85"><span class="surname">85.Al-Burooj</span><span class="engname">&nbsp;(The Constellations)</span><span class="numofverse">22</span></li><li class="suralistitem" id="suranum_86"><span class="surname">86.At-Taariq</span><span class="engname">&nbsp;(The Morning Star)</span><span class="numofverse">17</span></li><li class="suralistitem" id="suranum_87"><span class="surname">87.Al-A'laa</span><span class="engname">&nbsp;(The Most High)</span><span class="numofverse">19</span></li><li class="suralistitem" id="suranum_88"><span class="surname">88.Al-Ghaashiya</span><span class="engname">&nbsp;(The Overwhelming)</span><span class="numofverse">26</span></li><li class="suralistitem" id="suranum_89"><span class="surname">89.Al-Fajr</span><span class="engname">&nbsp;(The Dawn)</span><span class="numofverse">30</span></li><li class="suralistitem" id="suranum_90"><span class="surname">90.Al-Balad</span><span class="engname">&nbsp;(The City)</span><span class="numofverse">20</span></li><li class="suralistitem" id="suranum_91"><span class="surname">91.Ash-Shams</span><span class="engname">&nbsp;(The Sun)</span><span class="numofverse">15</span></li><li class="suralistitem" id="suranum_92"><span class="surname">92.Al-Lail</span><span class="engname">&nbsp;(The Night)</span><span class="numofverse">21</span></li><li class="suralistitem" id="suranum_93"><span class="surname">93.Ad-Dhuhaa</span><span class="engname">&nbsp;(The Morning Hours)</span><span class="numofverse">11</span></li><li class="suralistitem" id="suranum_94"><span class="surname">94.Ash-Sharh</span><span class="engname">&nbsp;(The Consolation)</span><span class="numofverse">8</span></li><li class="suralistitem" id="suranum_95"><span class="surname">95.At-Tin</span><span class="engname">&nbsp;(The Fig)</span><span class="numofverse">8</span></li><li class="suralistitem" id="suranum_96"><span class="surname">96.Al-Alaq</span><span class="engname">&nbsp;(The Clot)</span><span class="numofverse">19</span></li><li class="suralistitem" id="suranum_97"><span class="surname">97.Al-Qadr</span><span class="engname">&nbsp;(The Power, Fate)</span><span class="numofverse">5</span></li><li class="suralistitem" id="suranum_98"><span class="surname">98.Al-Bayyina</span><span class="engname">&nbsp;(The Evidence)</span><span class="numofverse">8</span></li><li class="suralistitem" id="suranum_99"><span class="surname">99.Az-Zalzala</span><span class="engname">&nbsp;(The Earthquake)</span><span class="numofverse">8</span></li><li class="suralistitem" id="suranum_100"><span class="surname">100.Al-Aadiyaat </span><span class="engname">&nbsp;(The Chargers)</span><span class="numofverse">11</span></li><li class="suralistitem" id="suranum_101"><span class="surname">101.Al-Qaari'a</span><span class="engname">&nbsp;(The Calamity)</span><span class="numofverse">11</span></li><li class="suralistitem" id="suranum_102"><span class="surname">102.At-Takaathur</span><span class="engname">&nbsp;(Competition)</span><span class="numofverse">8</span></li><li class="suralistitem" id="suranum_103"><span class="surname">103.Al-Asr</span><span class="engname">&nbsp;(The Declining Day, Epoch)</span><span class="numofverse">3</span></li><li class="suralistitem" id="suranum_104"><span class="surname">104.Al-Humaza</span><span class="engname">&nbsp;(The Traducer)</span><span class="numofverse">9</span></li><li class="suralistitem" id="suranum_105"><span class="surname">105.Al-Fil</span><span class="engname">&nbsp;(The Elephant)</span><span class="numofverse">5</span></li><li class="suralistitem" id="suranum_106"><span class="surname">106.Quraish</span><span class="engname">&nbsp;(Quraysh)</span><span class="numofverse">4</span></li><li class="suralistitem" id="suranum_107"><span class="surname">107.Al-Maa'un</span><span class="engname">&nbsp;(Almsgiving)</span><span class="numofverse">7</span></li><li class="suralistitem" id="suranum_108"><span class="surname">108.Al-Kawthar</span><span class="engname">&nbsp;(Abundance)</span><span class="numofverse">3</span></li><li class="suralistitem" id="suranum_109"><span class="surname">109.Al-Kaafiroon</span><span class="engname">&nbsp;(The Disbelievers)</span><span class="numofverse">6</span></li><li class="suralistitem" id="suranum_110"><span class="surname">110.An-Nasr</span><span class="engname">&nbsp;(Divine Support)</span><span class="numofverse">3</span></li><li class="suralistitem" id="suranum_111"><span class="surname">111.Al-Masad</span><span class="engname">&nbsp;(The Palm Fibre)</span><span class="numofverse">5</span></li><li class="suralistitem" id="suranum_112"><span class="surname">112.Al-Ikhlaas</span><span class="engname">&nbsp;(Sincerity)</span><span class="numofverse">4</span></li><li class="suralistitem" id="suranum_113"><span class="surname">113.Al-Falaq</span><span class="engname">&nbsp;(The Dawn)</span><span class="numofverse">5</span></li><li class="suralistitem" id="suranum_114"><span class="surname">114.An-Naas</span><span class="engname">&nbsp;(Mankind)</span><span class="numofverse">6</span></li>
						</ul>
					</div>
				</div>
			</div>
			
			<div class="table">
				<div class="tablecell optdiv">
					<span class="multiinput">
						<h3>Start from</h3><h3>per page</h3>
							<span><input type="number" value="1"  min="1" class="optinput" id="svnum"/></span>
							<span><input type="number" value="5" max="5" min="1" class="optinput" id="vppnum"/></span>
						<span class="updatemultiinput">
							<div id="updateversesetting" class="updatebutton">
								<div class="tableshow"><div class="tablecellshow">GO</div></div>
							</div>
						</span>
					</span>
				</div>
			</div>
						
						
			<div class="table">
				<div class="tablecell optdiv">
					<div class="choosecontentsettingstrans">
						<ul class="transul">
							<li>
								<span id="arabic_opt" class="langopt active"><input type="checkbox" id="arabic" class="optinput translang" checked="true" name="translang_arabic"><span class="transname"><div class="tableshow"><div class="tablecellshow">Arabic</div></div></span></span>
							</li>
							<li>
								<span id="english_opt" class="langopt active"><input type="checkbox" id="english" class="optinput translang" checked="true" name="translang_english"><span class="transname"><div class="tableshow"><div class="tablecellshow">English</div></div></span><span class="infotrans" id="trans_a"><div class="tableshow"><div class="tablecellshow">i</div></div></span></span>
							</li>
							<li>
								<span id="indonesian_opt" class="langopt"><input type="checkbox" id="indonesian" class="optinput translang" name="translang_indonesian"><span class="transname"><div class="tableshow"><div class="tablecellshow">Indonesian</div></div></span></span>
							</li>
							<li>
								<span id="mqs_opt" class="langopt"><input type="checkbox" id="mqs" class="optinput translang" name="translang_mqs"><span class="transname"><div class="tableshow"><div class="tablecellshow">M. Quraish Shihab</div></div></span><span class="infotrans" id="trans_m"><div class="tableshow"><div class="tablecellshow">i</div></div></span></span>			
							</li>
							<li>
								<span id="jalalayn_opt" class="langopt"><input type="checkbox" id="jalalayn" class="optinput translang" name="translang_jalalayn"><span class="transname"><div class="tableshow"><div class="tablecellshow">Tafsir Jalalayn</div></div></span><span class="infotrans" id="trans_t"><div class="tableshow"><div class="tablecellshow">i</div></div></span></span>
							</li>
						</ul>
						<span id="updatetrans" value="update" class="updatebutton"><div class="tableshow"><div class="tablecellshow">Update</div></div></span>
					</div>
				</div>
			</div>
									
									
			<div class="table">
				<div class="tablecell optdiv">
					<div class="choosecontentsettings searchsettings">
						<ul>
							<li>
								<span><input type="text" id="searchkeyword" value="keyword"></span>
							</li>
							<li class="portraitdual">
								<span class="optbg">
									<input type="radio" class="" id="searchincurrent" name="searchins" checked="checked"><span class="radiochecklabel active"><div class="tableshow"><div class="tablecellshow">Current</div></div></span>
									<input type="radio" class="" id="searchinall" name="searchins"><span class="radiochecklabel" id="searchinalllabel"><div class="tableshow"><div class="tablecellshow">All</div></div></span>
								</span>
							</li>
							<li>
								<div id="getsearch" class="updatebutton"><div class="tableshow"><div class="tablecellshow">Search</div></div></div>
							</li>
						</ul>
					</div>
				</div>
			</div>
												
												
			<div class="table">
				<div class="tablecell optdiv">
					<span class="multiinput">
						<h3 class="plain audiosett">Start</h3><h3 class="plain audiosett">End</h3>
							<span class="audiosett"><input type="number" value="1" min="1" class="optinput" id="audiostart"/></span>
							<span class="audiosett"><input type="number" value="7" min="1" class="optinput" id="audioend"/></span>
							<span class="audiosett tablecell" id="loopaudiosett"><span class="tablecellshow"></span><input type="checkbox" id="loopaudio" checked="false"/></span>
						<span class="updatemultiinput audiosett"><input type="button" id="updateaudiodesc" value="play" class="updatebutton"></span>
						<audio src="" preload="true" id = "textaudio" mediagroup="quranaudio" controls="true" name="textaudio"></audio>
					</span>
				</div>
			</div>

			
			
			<div class="table">
				<div class="tablecell">
					<div class="optdiv">
						<span class="settingform singleline">
							<input type="radio" id="Bukharibook_1" name="hadithchoose" checked="checked" class="choosehadith <?php echo $pagevar['mobile']; ?>"><span class="radiochecklabel"><div class="tableshow"><div class="tablecellshow">Bukhari</div></div></span>
							<input type="radio" id="Muslimbook_2" name="hadithchoose" class="choosehadith <?php echo $pagevar['mobile']; ?>"><span class="radiochecklabel"><div class="tableshow"><div class="tablecellshow">Muslim</div></div></span>
						</span>						
					</div>
				</div>
			</div>
						
			
			<div class="contentofcontent hadithbookchaptersettings" id="chaptersetting">
				<div id="hadithbookchaptercontainer">
					<div class="optdiv list <?php echo $pagevar['mobile']; ?>" id="chaptlistcont">
						<ul id="chaptlist">	</ul>
					</div>
				</div>
			</div>
			
			<div class="contentofcontent hadithbookchaptersettings" id="hadithbooksetting">
				<div id="hadithlistcontainer">
					<div class="optdiv list" id="hadithlistcont">
						<ul id="hadithlist"></ul>
					</div>
				</div>
			</div>
			
									
									
			<div class="table">
				<div class="tablecell">
					<div class="optdiv hadithsearchoptdiv">
						<h3 id="searchhadithtext"><span class="plain">Search in</span> Bukhari</h3>
						<span class="settingform"><input type="text" id="searchhadith" value="keyword"></span>
						<span class="settingform dualline">
							<input type="radio" id="searchincurrentimam" name="searchin" checked="checked" class=""><span class="radiochecklabel active"><div class="tableshow"><div class="tablecellshow">Current</div></div></span>
							<input type="radio" id="searchinallimam" name="searchin" class=""><span class="radiochecklabel" id="searchinallimam"><div class="tableshow"><div class="tablecellshow">All</div></div></span>
						</span>
						<span class="settingform">
							<div id="getsearchhadith" class="updatebutton"><div class="tableshow"><div class="tablecellshow">Search</div></div></div>
						</span>
					</div>
				</div>
			</div>
		</div>
		
		
		<div id="content" class="contentofcontent active">
			<div id="verse">
				<div id="loadingnotif"></div>
				<div id="versecontainer">
					<ul id="verselist"></ul>
				</div>
				<div id="searchdesc" class="show"><span id="searchdesctext">Al-Fatihah</span></div>
			</div>
		</div>
		<div id="contenttwo" class="contentofcontent">
			<div id="hadithcontent">
				<div id="hadithloadingnotif"></div>
				<div id="hadithcontainer">
					<div id="hadithmessage"><span>Select from the available options</span></div>
					<ul id="hadithcontentlist"></ul>
				</div>
				<div id="hadithsearchdesc" class="show"><span id="hadithsearchdesctext"></span></div>
			</div>
		</div>
	</div>

	<div id="sidebar">
		<div id="opqbg"></div>
		<div id="hadithopt">
			<div id="hadithchoose" class="contentopt"></div>
			<div id="hadithbookchoose" class="contentopt"></div>
			<div id="hadithsearch" class="contentopt"></div>
		</div>
		<div id="quranopt" class="active">
			<div id="prevaya" class="contentopt navi"></div>
			<div id="nextaya" class="contentopt navi"></div>
			<div class="contentopt" id="contentsettingsopt"></div>
		</div>
		
		
		<div id="globalmenu">
			<div id="viewswitch" class="globalmenu"></div>			
			<div id="asmaulhusna" class="globalmenu"></div>
			<div class="globalmenu separator"></div>
			<div id="about" class="globalmenu"></div>
		</div>
	</div>