var arabictext;
var qtrans = [];
var qlangmap = [];
var currentsura = 1;
var currentlang = [];
var startfrom = 1;
var verseperpage = 5;
var searchresult = [];
var searchkeylang = [];
var searchpage = false;
var scrolledsearchpage = [];
var suranames = [];
var searchresultmap = [];
var loading = false;
var audio = false;
var audioplaying = false;
var currentaudio = '';
var acontroller = [];
var startau = 0;
var endau = 0;
var currentbg = 'carpet';
var current99=0;
var page = 1;
var chaptview = false;
var book = [];
var chapters = [];
var cimam = 1;
var chapdownloaded = [];
var hadithtext = [];
var currentbook = 0;
var sajda = [];
var juz = [];
var allowedcompany = [];
var scrolled = 0;
var pagescrolled = 0;
var loopaudio = false;
var startauori = false;
var asmaulhusnascrolled=0;
var duetrecital=false;


$('window').ready(function(){
	qlangmap[0] = 	'indonesian';
	qlangmap[1] = 	'english';
	qlangmap[2] = 	'jalalayn';
	qlangmap[3] = 	'mqs';
	qlangmap[4] = 	'arabic';

	currentlang[0] = 4;
	currentlang[1] = 1;
	
    getLocalStorage();    
    getsuranames();
	setdefaults();
	searchkeyword();
	initquran();
	suralist();

	navipage();
	updateversesett();
	updatetranslation();
	getsearch();
	audiosettings();
	about();
	bgselect();
	asmaulhusna();
	twopage();
	translator();

	inithadith();
	hadithchoose();
	searchhadith();
	keywordhadith();

	audio  =  new Audio("");
	
	allowedcompany[allowedcompany.length] = ' ';
	allowedcompany[allowedcompany.length] = '(';
	allowedcompany[allowedcompany.length] = ')';
	allowedcompany[allowedcompany.length] = '.';
	allowedcompany[allowedcompany.length] = ',';
	allowedcompany[allowedcompany.length] = '-';
	allowedcompany[allowedcompany.length] = '"';
	allowedcompany[allowedcompany.length] = "'";
	allowedcompany[allowedcompany.length] = '!';
	allowedcompany[allowedcompany.length] = ':';
	allowedcompany[allowedcompany.length] = ';';
	allowedcompany[allowedcompany.length] = '?';
	allowedcompany[allowedcompany.length] = '-';
	
	scrolled = $('#versecontainer')[0].scrollTop;
});

function inithadith(){
	$.ajax({
		url:"./",
		data:{app:appname,p:'ajax',a:'hadith',d:{hadith:1}},
		type:"POST"
	}).done(function(msg){
		bookjson = $.parseJSON(msg);
		$.each(bookjson, function(i,v){
			$.each(v, function(ii,vv){
				index = book.length;
				book[index] = [];
				book[index]['imam'] = parseInt(i);
				book[index]['title'] = vv['title'];
				book[index]['id'] = parseInt(vv['id']);
			});			
		});

		var bli = '';
		$.each(book, function(i,v){
			if(v['imam'] === 1){
				bli += '<li class="booklistitem" id="book_'+ v['id'] +'">'+ v['title'] +'</li>';
			}
		});
		$('#hadithlist').html(bli);
		booklist();
	});
}

function showhadithload(){
	$('#hadithcontainer').addClass('opaque');
	$('#hadithloadingnotif').css('display','block');
}
function hidehadithload(){
	$('#hadithcontainer').removeClass('opaque');
	$('#hadithloadingnotif').css('display','none');
}

function keywordhadith(){
	$('#searchhadith').on('click',function(){
		if($(this).val() === 'keyword'){
			$(this).val('');
		}
	});
	$('#searchhadith').on('blur', function(){
		if($(this).val() === '')
			$(this).val('keyword');
	});
}
function showmessage(message){
	$('#hadithmessage').html('<span>'+message+'</span>');	
	$('#hadithmessage').show();
	$('#hadithcontentlist').hide();
}
function hidemessage(){
	$('#hadithmessage').hide();
	$('#hadithcontentlist').show();
}
function searchhadith(){
	$('#getsearchhadith').on('click',function(){
		key = $('#searchhadith').val();
		if(key === "" || key === "keyword")
			return;
		
		var serbook = 0;
		if($('#searchincurrentimam').prop('checked')){
			if(currentbook === 0){
				showmessage('select a book');
				return;
			}
			else{
				hidemessage();
				serbook = currentbook;	
			}
		}
		
		searchres = [];
		showhadithload();
		$.ajax({
			url:"./",
			data:{app:appname,p:'ajax',a:'hadithkey',d:{hadithkey:key, imam:cimam, book:serbook}},
			type:"POST"
		}).done(function(msg){
			hadithsearched = $.parseJSON(msg);
			$.each(hadithsearched, function(i,v){
				index = searchres.length;
				searchres[index] = [];
				searchres[index]['book'] = v['book'];
				searchres[index]['chap'] = v['chap'];
				searchres[index]['notes'] = v['notes'];
				searchres[index]['hadith'] = v['hadith'];
			});
			writehadithsearch(searchres);
			hidehadithload();
		});
	});
}

function writehadithsearch(searchres){
	var searchtext = '';
	var number = 0;
	var chapter = 0;
	var chaptercount = 0;
	var xpl=[];
	$.each(searchres, function(i,v){
		number+=1;
		border = ' border';
		if(v['chap'] !== chapter){
			searchtext += '<li class="hadithtext chapt">'+v['chap']+'</li>';
			chapter = v['chap'];
			chaptercount +=1;
		}

		if(i === searchres.length-1){
			border = '';
		}
		xpl = v['hadith'].toLowerCase().split(key.toLowerCase());
		v['hadith'] = xpl.join('<span class="searchkey">'+key+'</span>');
		if(v['notes'] !== ''){
			searchtext += '<li class="hadithtext">'+ number +'. '+v['hadith']+'</li>';
			searchtext += '<li class="hadithtext notes'+ border +'">'+v['notes']+'</li>';
		}
		else{
			searchtext += '<li class="hadithtext'+ border +'">'+ number +'. '+v['hadith']+'</li>';
		}
	});

	$('#hadithsearchdesctext').html('"%'+key+'%" found in '+number+' hadith');
	$('#hadithcontentlist').html(searchtext);
	$('#hadithmessage').hide();
	$('#hadithcontentlist').css('display','block');
}

function hadithchoose(){
	$('.choosehadith').on('click', function(){
		imam = this.id.substr(0,this.id.indexOf('book'));
		$('#searchhadithtext').html('<span class="plain">Search in</span> '+imam);
		$('#hadithsearchdesctext').html("");
		cimam  = parseInt(this.id.substr(this.id.indexOf('_')+1, this.id.length ));
		$('#hadithcontentlist').html('');
		hidemessage();
		currentbook=0;
		if(chaptview){
				$('#chaptlistcont').animate({'height':'0%'},'fast', function(){
				chaptview = false;
				$('#chapter').addClass('hide'); 
				$('#chaptlistcont').addClass('hide'); 
				populatebook(cimam);	
			});	
		}
		else{
			populatebook(cimam);	
		}
	});
}

function populatebook(cimam){
	var bli = '';			
		$.each(book, function(i,v){
			if(v['imam'] === cimam){
				bli += '<li class="booklistitem" id="book_'+ v['id'] +'">'+ v['title'] +'</li>';
			}
		});
		$('#hadithlist').html(bli);
		booklist();
}

function writehadith(){
	hcontent = '';
	count = 0;
	$.each(hadith, function(i,v){
		border = ' border';
		if(i === hadith.length-1){
			border = '';
		}
		if(v['notes'] !== ''){
			hcontent += '<li class="hadithtext">'+( i+1) +'. '+v['hadith']+'</li>';
			hcontent += '<li class="hadithtext notes'+ border +'">'+v['notes']+'</li>';
		}
		else{
			hcontent += '<li class="hadithtext'+ border +'">'+ (i+1) +'. '+v['hadith']+'</li>';
		}
		count+=1;
	});

	$('#hadithsearchdesctext').html(count+' hadith in current chapter');
	$('#hadithcontentlist').html(hcontent);
	$('#hadithmessage').hide();
	$('#hadithcontentlist').css('display','block');
}

function chapterlist(){
	$('.chaplistitem').on('click', function(){
		$('#hadithsearchdesctext').html("");
		$('.chaplistitem').removeClass('selected');
		$(this).addClass('selected');
		chapids = this.id.substr(this.id.indexOf('_')+1, this.id.length );
		chapid = chapids.substr(0, chapids.indexOf('_') );
		var hadithcontent = '';
		$.each(chapters[cimam], function(ci,cv){
			if(cv['book'] === currentbook){
				if(cv['id'] ===  chapid){
					hadith = cv['texts'];
					return false;
				}
			}
		});
		
		writehadith();
	});
}

function booklist(){
	$('.booklistitem').on('click', function(){
		$('#hadithcontentlist').html('');
		$('.booklistitem').removeClass('selected');
		$('#hadithsearchdesctext').html("");
		$(this).addClass('selected');
		currentbook = this.id.substr(this.id.indexOf('_')+1, this.id.length);
		if($.inArray(currentbook, chapdownloaded[cimam]) === -1){
			if(typeof(chapters[cimam])  === 'undefined'){
				chapters[cimam] 			= [];
				chapdownloaded[cimam] 	= [];
				hadithtext[cimam]			= [];
			}
			$.ajax({
				url:"./",
				data:{app:appname,p:'ajax',a:'bookreq',d:{bookreq:currentbook}},
				type:"POST"
			}).done(function(msg){
				chapdownloaded[cimam][chapdownloaded[cimam].length] = currentbook;
				chapts = $.parseJSON(msg);
				$.each(chapts, function(i,v){
					chapix = chapters[cimam].length;
					chapters[cimam][chapix] = [];
					chapters[cimam][chapix]['id'] = v['id'];
					chapters[cimam][chapix]['title'] = v['title'];
					chapters[cimam][chapix]['chapter'] = v['numbering'];
					chapters[cimam][chapix]['book'] = currentbook;
					chapters[cimam][chapix]['texts'] = v['hadithtext'];
				});

				var chaplist = '';
				var chapcount = 0;
				$.each(chapters[cimam], function(i,v){
					if(v['book'] === currentbook){
						chapcount+=1;
						chaplist += '<li class="chaplistitem" id="chapt_'+ v['id'] +'_'+v['chapter']+'">'+ v['title'] +'</li>';
					}
				});
				$('#chaptlist').html(chaplist);
				$('#hadithsearchdesctext').html(chapcount+' chapter in current book');
				chapterlist();
				if(!chaptview){
					chaptview = true;
					$('#chaptlistcont').animate({'height':'34%'}, function(){
						$('#chapter').removeClass('hide'); 
						$('#chaptlistcont').removeClass('hide'); 		
					});	
				}
			});
		}
		else{			
			var chaplist = '';
			var chapcount = 0;
			$.each(chapters[cimam], function(i,v){
				if(v['book'] === currentbook){
					chapcount+=1;
					chaplist += '<li class="chaplistitem" id="chapt_'+ v['id'] +'_'+v['chapter']+'">'+ v['title'] +'</li>';
				}
			});
			$('#chaptlist').html(chaplist);
			$('#hadithsearchdesctext').html(chapcount+' chapter in current book');
			chapterlist();
			if(!chaptview){
				chaptview = true;
				$('#chaptlistcont').animate({'height':'34%'}, function(){
					$('#chapter').removeClass('hide'); 
					$('#chaptlistcont').removeClass('hide'); 		
				});	
			}
		}
	});

}
function twopage(){
	$('#viewswitch').on('click',function(){
		if(page === 1){
			page = 2;
			$('#about').hide();
			$('#asmaulhusna').hide();
			$('#bgselectcont').hide();
			$('#viewswitch').animate({'left' : '0'}, function(){
				$('#viewswitch').addClass('hadith');
			});

			$('#content').animate({'margin-left' : '-50%'}, function(){
			});
		}
		else{
			page = 1;
			$('#viewswitch').animate({'left' : '96.5%'},function(){
				$('#viewswitch').removeClass('hadith');
			});

			$('#content').animate({'margin-left' : '0px'}, function(){
				$('#about').show();
				$('#asmaulhusna').show();
				$('#bgselectcont').show();
			});
		}
	});
}
function asmaulhusna(){
	$('#asmaulhusna').on('click',
		function(){
			$('#content').addClass('opaque');
			$('#thenames').show('fast', function(){
				$('#close99').show();
				$('#thenamescontainer').scrollTop(asmaulhusnascrolled);
			});
		}
	);
	$('#close99').on('click',function(){
	    asmaulhusnascrolled = $('#thenamescontainer')[0].scrollTop;
	    userdata.update('asmaulhusnascrolled');
		$('#thenames').hide();
		$('#close99').hide();
		$('#content').removeClass('opaque');
	});
	$('.oneof99title').on('click',function(){
		clearTimeout(current99);
		trans =$(this).siblings('.transoneof99');
		$(this).css('display','none');
		$(trans).css('display','table-cell');
		current99 = setTimeout( function(){
			$('.oneof99title').siblings('.transoneof99').css('display','none');
			$('.oneof99title').css('display','table-cell');
		}, 5000);
	});
	$('.transoneof99').on('click',function(){
		$(this).css('display','none');
		$(this).siblings('.oneof99title').css('display','table-cell');
	});
}

function translator(){
	$('.infotrans').on('click',
		function(event){
		    event.stopPropagation();
			$('#content').addClass('opaque');
			$('#translatorprof_'+this.id.substr(this.id.indexOf('_')+1)).show('fast', function(){
				$('#closetrans_'+this.id.substr(this.id.indexOf('_')+1)).show();
			});
		}
	);

	$('#closetrans_a').on('click',function(){
		$('#translatorprof_a').hide();
		$('#closetrans_a').hide();
		$('#content').removeClass('opaque');
	});

	$('#closetrans_m').on('click',function(){
		$('#translatorprof_m').hide();
		$('#closetrans_m').hide();
		$('#content').removeClass('opaque');
	});

	$('#closetrans_t').on('click',function(){
		$('#translatorprof_t').hide();
		$('#closetrans_t').hide();
		$('#content').removeClass('opaque');
	});
	
	$('.langopt').on('click',function(){
	    var inputopt = $(this).children('.optinput');
	    if($(inputopt).prop('checked')){
	        $(this).children('.optinput').prop('checked',false);
	        return;
	    }
	    $(this).children('.optinput').prop('checked',true);
	});
}

function bgselect(){
	$('.bgselect').on('click',function(){
		$('body').removeClass('bg'+currentbg);
		$('#thenames').removeClass(currentbg);

		currentbg = this.id.substr(7);
		$('body').addClass('bg'+currentbg);
		$('#thenames').addClass(currentbg);
	});
}

function about(){
	$('#about').on('click',
		function(){
			$('#content').addClass('opaque');
			$('#thei').show('fast', function(){
				$('#closethei').show();
			});
		}
	);
	$('#closethei').on('click',function(){
		$('#thei').hide();
		$('#closethei').hide();
		$('#content').removeClass('opaque');
	});
}

function playrecital(){
	if(!audioplaying){
		startau 	= parseInt($('#audiostart').val());
		startauori  = startau;
		endau 		= parseInt($('#audioend').val());
		versetotal	= qtrans[currentsura].length-1;

		startau 	= Math.min(startau, versetotal);
		endau 		= Math.min(endau, versetotal);

		if(startau > endau){
			endau = startau;
		}

		$('#audiostart').val(startau);
		$('#audioend').val(endau);

		if(startau >= startfrom){
			startfrom = startau;
			$('#svnum').val(startfrom);
			writepage();
		}
		else{
			if(startau+verseperpage <= startfrom){
				startfrom = startau;
				$('#svnum').val(startau);
				writepage();
			}
		}
	
		if(startau <= endau){
			audio.removeEventListener('ended',endplaying);
			audioplaying = true;
			playmultiple();
			$('#updateaudiodesc').val('stop');
		}
	}
	else{
	    $('#updateaudiodesc').val('play');
		endplaying();
					
		audioplaying = false;
		audio.removeEventListener('ended',endplaying);
		audio.removeEventListener('ended',playmultiple);
	}
}

function audiosettings(){
    $('#loopaudio').on('click',function(event){
        event.stopPropagation();
        
        if($(this).attr('class').indexOf('active') === -1){
            $(this).addClass('active');
            loopaudio = true;
        }
        else{
            $(this).removeClass('active');
            loopaudio = false;
        }
    });
	$('#audiostart').on('blur',function(){
		if( parseInt($('#audiostart').val()) > parseInt($('#audioend').val()) ){
			$('#audioend').val($('#audiostart').val());
		}
	});
	$('#updateaudiodesc').on('click',function(){
	    playrecital();
	});
	$('#audioend').on('blur',function(){
		if (audioplaying) {
			endau = parseInt($(this).val());
		}
	});
}

function playmultiple(){
	currentaudio = currentsura+'_'+startau;
	if(startau === startfrom){
		$('#svnum').val(startfrom);
		writepage();
	}
	else{
		if(startau >1){
			$('#vn_'+currentsura+'_'+(startau-1)).removeClass('playing');
		}
	}
	$('#audiostart').val(startau);
	 
	if(startau === endau){
	    if(currentlang.length==2 && $.inArray(1,currentlang) !==-1 && $.inArray(4,currentlang) !==-1){
	        if(duetrecital===0){
    	        audio.removeEventListener('ended',playmultiple);
        		audio.addEventListener('ended',endplaying);   
    	    }
    	    else{
    	        audio.removeEventListener('ended', playmultiple);
    		    audio.addEventListener('ended',playmultiple);
    	    }
	    }
	    else{
	        audio.removeEventListener('ended', playmultiple);
		    audio.addEventListener('ended',endplaying);
	    }
	}
	else{
		audio.removeEventListener('ended', playmultiple);
		audio.addEventListener('ended',playmultiple);
	}
	 
	if(currentlang.length==2 && $.inArray(1,currentlang) !==-1 && $.inArray(4,currentlang) !==-1){
	    if(duetrecital === false){
	        duetrecital = 0;
	        audio.src   = './uploads/one14/audio/'+currentsura+'/'+startau+'.mp3';
	    }
	    else if(duetrecital===0){
	        duetrecital = false;
	        audio.src   = './uploads/one14/transaudio/'+currentsura+'/'+startau+'.mp3';
	        startau++;
	    }
	}
	else{
	    if($.inArray(4,currentlang) !==-1){
    	    audio.src = './uploads/one14/audio/'+currentsura+'/'+startau+'.mp3';
    	}
    	else{
    	    audio.src = './uploads/one14/transaudio/'+currentsura+'/'+startau+'.mp3';
    	}
    	startau++;
	}
    audio.play();
	$('#vn_'+currentaudio).addClass('playing');
	document.getElementById('vn_'+currentaudio).scrollIntoView();
}

function endplaying(){
	audio.pause();
	$('#vn_'+currentaudio).removeClass('playing');
	audioplaying = false;
	currentaudio = '';
	
	if(loopaudio && $('#updateaudiodesc').val() == 'stop'){
	    $('#audiostart').val(startauori);
	    playrecital();
	}
	else{
	    $('#updateaudiodesc').val('play');
	}
}

function playverse(){
	$('.arabic').on('click', function(){
		versenumplay = parseInt(this.id.substr(this.id.indexOf('_')+1));
		if(audioplaying){
			audio.pause();
			$('#vn_'+currentaudio).removeClass('playing');
			if(currentaudio == this.id){
				currentaudio = '';
				audioplaying = false;
				$('#updateaudiodesc').val('play');
			}
			else{
				$('#audiostart').val(versenumplay);
				$('#audioend').val(versenumplay);
				audioplaying = true;
				audio.src = './uploads/one14/audio/'+currentsura+'/'+versenumplay+'.mp3' ;
		
				audio.play();
				currentaudio = this.id;
				$('#vn_'+currentaudio).addClass('playing');
			}
		}
		else{
			$('#audiostart').val(versenumplay);
			$('#audioend').val(versenumplay);
			audioplaying = true;
			audio.src = './uploads/one14/audio/'+currentsura+'/'+versenumplay+'.mp3';

			audio.play();
			audio.removeEventListener('ended',endplaying);
			audio.addEventListener('ended',endplaying);
			currentaudio = this.id;
			$('#vn_'+currentaudio).addClass('playing');
		}
	})
}

function getsuranames(){
    $.each($('#suralist').children(), function(i,v){
        suranames[i+1] = $(v).html();
    });
}

function setdefaults(){
	$('#svnum').val(1);
	$('#vppnum').val(5);
	$('#audiostart').val(1);
	$('#audioend').val(7);

	$('#searchkeyword').val('keyword');

	$('#arabic').prop('checked',true);
	$('#english').prop('checked',true);
	$('#indonesian').prop('checked',false);
	$('#mqs').prop('checked',false);
	$('#jalalayn').prop('checked',false);

	$('#Bukharibook_1').prop('checked',true);
	$('#searchincurrentimam').prop('checked',true);
	$('#searchhadith').val('keyword');
	
	$('#svnum').on('keydown',function(key){
	    key.stopPropagation();
	    
	});
	$('#vppnum').on('keydown',function(key){
	    key.stopPropagation();
	});
	$('#audiostart').on('keydown',function(key){
	    key.stopPropagation();
	});
	$('#audioend').on('keydown',function(key){
	    key.stopPropagation();
	});
	$('#searchkeyword').on('keydown',function(key){
	    key.stopPropagation();
	});
	$('#searchhadith').on('keydown',function(key){
	    key.stopPropagation();
	});
}

function getLang(lang,suraid){
    showloadingnotif();
    $.ajax({
        url:"./",
		data:{app:appname,p:'ajax',a:'reqlang',d:{reqlang:lang,suraid:suraid}},
        type:"POST"
    }).done(function(msg){
        newlang = $.parseJSON(msg);
        $.each(newlang,function(i,v){
                $.each(v, function(ii,vv){
                        $.each(vv,function(lk,lv){
                                qtrans[i][ii][lk] = lv;
                        });
                });
        });
        qtrans[suraid][0] = $.merge(qtrans[suraid][0], langarray(lang));
        if(searchpage){
            searchkey();
            return;
        }
        writepage();
        hideloadingnotif();
    });
}

function initSura(sid,lang){
    showloadingnotif();
	$.ajax({
        url:"./",
		data:{app:appname,p:'ajax',a:'sura',d:{sura:sid,lang:lang}},
        type:"POST"
	}).done(function(msg){
		var versecount = 0;
		var qtext = $.parseJSON(msg);
		$.each(qtext, function(i,v){
            i = parseInt(i);
		    $.each(v,function(ii,vv){
                ii = parseInt(ii);
    			versecount++;
		        if(!$.isArray(qtrans[i])){
		            qtrans[i] = [];    
                    qtrans[i][0] = langarray(lang);
		        }
		        if(!$.isArray(qtrans[i][ii])){
		            qtrans[i][ii] = [];
		        }
    			$.each(vv,function(lk,lv){
    			        qtrans[i][ii][lk] = lv;
    			});
		    });
		});
		currentsura = sid;
		startfrom = $('#svnum').val();
		verseperpage = parseInt($('#vppnum').val());
		$('#svnum').attr('max', versecount);

		writepage();
		$('.suralistitem').removeClass('selected');
		$('#suranum_'+currentsura).addClass('selected');
		$('#suranum_'+currentsura)[0].scrollIntoView();

		$('#audiostart').val(1);
		$('#audioend').val(versecount);

        hideloadingnotif();
        
        if(startrandomsuracb.displaysuracb !== false){
            startrandomsuracb.playrandom();
        }
	});
}

function initquran(){
	juz[0] = '1_1';
	juz[1] = '2_142';
	juz[2] = '2_253';
	juz[3] = '3_93';
	juz[4] = '4_24';
	juz[5] = '4_148';
	juz[6] = '5_82';
	juz[7] = '6_111';
	juz[8] = '7_88';
	juz[9] = '8_41'; 

	juz[10] = '9_93';
	juz[11] = '11_6';
	juz[12] = '12_53';
	juz[13] = '15_1';
	juz[14] = '17_1';
	juz[15] = '18_75';
	juz[16] = '21_1';
	juz[17] = '23_1';
	juz[18] = '25_21';
	juz[19] = '27_56';

	juz[20] = '29_46';
	juz[21] = '33_31';
	juz[22] = '36_28';
	juz[23] = '39_32';
	juz[24] = '41_47';
	juz[25] = '46_1';
	juz[26] = '51_31';
	juz[27] = '58_1';
	juz[28] = '67_1';
	juz[29] = '78_1';

	sajda[0] = '7_206';
	sajda[1] = '13_15';
	sajda[2] = '16_50';
	sajda[3] = '17_109';
	sajda[4] = '19_58';
	sajda[5] = '22_18';
	sajda[6] = '22_77';
	sajda[7] = '25_60';
	sajda[8] = '27_26';
	sajda[9] = '38_24';

	sajda[10] = '84_21';
	sajda[11] = '32_15';
	sajda[12] = '41_38';
	sajda[13] = '53_62';
	sajda[14] = '96_19';

    showloadingnotif();
    $.ajax({
        url:"./",
		data:{app:appname,p:'ajax',a:'sura',d:{sura:1,lang:getpostlang(currentlang)}},
        type:"POST"
    }).done(function(msg){
        arabictext = $.parseJSON(msg);
        $.each(arabictext, function(i,v){
            $.each(v,function(ii,vv){
                if(!$.isArray(qtrans[i])){
                    qtrans[i] = [];   
                    qtrans[i][0] = currentlang;
                }
                if(!$.isArray(qtrans[i][ii])){
                    qtrans[i][ii] = [];
                }
		$.each(vv,function(lk,lv){
	                qtrans[i][ii][lk] = lv;
		});
            });
        });
	$('#svnum').attr('max', 7);
	writepage();
	$('#suranum_1').addClass('selected');
        hideloadingnotif();
    });  
}

function writepage(){
    if(startfrom === -1){
        var modus = ((qtrans[currentsura].length-1) % verseperpage);
        modus = modus == 0 ?  verseperpage : modus;
        startfrom = (qtrans[currentsura].length-1) - parseInt(modus) +1;
        $('#svnum').val(startfrom);
        $('#audiostart').val(startfrom);
        $('#audioend').val(qtrans[currentsura].length -1);
    }

	$('#verselist').html('');
	for(var i=1;i<=verseperpage;i++){
		if(i> 1){
			 $('#verselist').append('<li class="verseseparator"></li>');
		}
		$.each(currentlang,function(i,v){
			writetext(currentsura,startfrom,v);
		});
		startfrom++;
		if(qtrans[currentsura].length === startfrom  ){
			break;
		}
	}
	$('#verselist').children('li')[0].scrollIntoView();
	playverse();
	if(audioplaying)
		$('#vn_'+currentaudio).addClass('playing');
		
	$('#versecontainer').scrollTop(0);
	scrolled = 0;
}

function writetext(sn,an,lang){
	var langclass = 'translation';
	var versenum = '';
		if(qlangmap[lang] === 'arabic'){
			if($.inArray(sn+'_'+an, sajda) !== -1){
				langclass += ' sajda';
			}
			if($.inArray(sn+'_'+an, juz)  !== -1 ){
				langclass += ' juz';
			}
			langclass += ' arabic';
		}
		if($.inArray(lang,currentlang) === 0){
			versenum = '<span class="versenum" id="vn_'+sn+'_'+an+'">'+an+'</span>';
		}
		if(lang === (currentlang[currentlang.length-1]) ){
			langclass += ' lastlang';
		}
	    $('#verselist').append('<li class="'+langclass+'" id="'+sn+'_'+an+'">'+qtrans[sn][an][lang]+versenum+'</li>');
}

function getpostlang(thelang){
	var postlang = '';
	$.each(thelang,function(i,v){
		postlang += v+',';
	});
	postlang = postlang.substr(0, (postlang.length -1) );
	return postlang;
}
function getlangtext(thelang){
    var langtext = '(';
    $.each(thelang, function(i,v){
        langtext += qlangmap[v]+',';
    });
    langtext = langtext.substr(0,(langtext.length-1))+')';
    return langtext;
}
function langarray(langstring){
    var langstringcontent = langstring;
    var langarr = [];
    var commapos = langstring.indexOf(',');
    while(commapos !== -1){
        langarr[langarr.length] = parseInt(langstringcontent.substr(commapos-1,commapos));
        langstringcontent       = langstringcontent.substr(commapos+1);
        commapos                = langstringcontent.indexOf(',');
    }
    langarr[langarr.length] = parseInt(langstringcontent);
    return langarr;
}
function searchkeyword(){
	$('#searchkeyword').on('click',function(){
		if($(this).val() === 'keyword'){
			$(this).val('');
		}
	});
	$('#searchkeyword').on('blur',function(){
		if($(this).val() === ''){
			$(this).val('keyword');
		}
	});
	$('#searchkeyword').on('keyup',function(key){
	    if(key.which == 13){
	        if($(this).val() !== ''){
	            searchkey();
	        }
	    }
	});
	$('.searchscope').on('click',function(event){
	    event.stopPropagation();
	    $(this).prev().prop('checked',true);
	});
}

function suralist(){
    $('.suralistitem').on('click',function(){
	    endplaying();
        var suraid = parseInt(this.id.substr(8));
        if(searchpage){
            resetsearchpage();
            currentsura = 0;
        }
        displaysura(suraid,true);
    });    
}  
function displaysura(suraid,startover){
    if(currentsura !== suraid){
        currentsura = suraid;
        $('.suralistitem').removeClass('selected');
        $('#suranum_'+suraid).addClass('selected');	
        $('#suranum_'+suraid)[0].scrollIntoView();
        if(!$.isArray(qtrans[suraid])){
            if(startover){
                $('#svnum').val(1);
                startfrom = 1;   
            }
            else{
                startfrom = -1;
            }
            initSura(suraid,getpostlang(currentlang));
        }
        else{
            if(startover){
                startfrom = 1;   
                $('#svnum').val(1);
                $('#audiostart').val(1);
	            $('#audioend').val(qtrans[suraid].length -1);
            }
            else{
                startfrom = -1;
            }
            getlang     = [];
            $.each(currentlang, function(i,v){
                if(typeof(qtrans[currentsura][1][v]) === 'undefined' ){
                    getlang[getlang.length] = v;
                }
            });
            if(getlang.length > 0){
                getLang(getpostlang(getlang), currentsura);
            }
            else{
                writepage();
            }
            
            if(startrandomsuracb.displaysuracb !== false){
                startrandomsuracb.playrandom();
            }
        }
    }
}
function navipage(){
	$('#prevaya').on('click',function(){
		if(startfrom === (verseperpage+1) || startfrom <= verseperpage)
			return;

		if(startfrom % verseperpage === 0 && verseperpage > 1)
			startfrom += 1;
		else if(startfrom === qtrans[currentsura].length && startfrom % verseperpage > 1)
			startfrom +=  (verseperpage -  ((qtrans[currentsura].length) % verseperpage)) +1;
		

		startfrom  = Math.max(startfrom  - (verseperpage*2),1);
		$('#svnum').val(startfrom);

		writepage();
	});
	$('#nextaya').on('click',function(){
		if(startfrom === qtrans[currentsura].length)
			return;

		$('#svnum').val(startfrom);
		$('#audiostart').val(startfrom);
		writepage();
	});
	$('.optinput').on('keydown',function(event){
	    event.stopPropagation();
	    if(event.which !== 13){
	        if(!(event.which == 38 || event.which == 40)){
	            bodykeyhandler(event);   
	        }
	        return;
	    }
	    switch($(this).attr('id')){
	       case 'svnum':
	       case 'vppnum':
	           updateversesettfn();
	       break;
	       case 'audiostart':
	       case 'audioend':
	           playrecital();
	       break;
	       default:
	       break;
	    }
	});
	$('body').on('keydown',function(key){
	    bodykeyhandler(key);
	});
}

function pdfsura(){
    window.open('./?app='+appname+'&p=ajax&a=pdfsura&d[suraid]='+currentsura);
}

function bodykeyhandler(key){
    if(key.ctrlKey){
        return;
    }
    if(key.which == 114){
        key.preventDefault();
        
        playrecital();
    }
    else if(key.which == 113){
        key.preventDefault();
        
        startrandomsura();
    }
    else if(key.which == 119){
        key.preventDefault();
        
        pdfsura();
    }
    else if(key.which === 33){
        key.preventDefault();
        if(startfrom === (verseperpage+1) || startfrom <= verseperpage){
            var suraid = currentsura-1;
            if(suraid > 0){
                displaysura(suraid,false);
            }
		    return;
        }
		if(startfrom % verseperpage === 0 && verseperpage > 1)
			startfrom += 1;
		else if(startfrom === qtrans[currentsura].length && startfrom % verseperpage > 1)
			startfrom +=  (verseperpage -  ((qtrans[currentsura].length) % verseperpage)) +1;
		

		startfrom  = Math.max(startfrom  - (verseperpage*2),1);
		$('#svnum').val(startfrom);
		$('#audiostart').val(startfrom);
		
		writepage();
    }
    else if(key.which === 34){
        key.preventDefault();
        if(startfrom === qtrans[currentsura].length){
            var suraid = currentsura+1;
            if(suraid <= 114){
                displaysura(suraid,true);
            }
		    return;
        }

		$('#svnum').val(startfrom);
		$('#audiostart').val(startfrom);
		writepage();
    }
    else if(key.which == 40){
        key.preventDefault();
        
        pagescrolled = $('#versecontainer')[0].scrollTop;
        
        pagescrolled += 30;
        $('#versecontainer').scrollTop(pagescrolled);
        scrolled = $('#versecontainer')[0].scrollTop;
    }
    else if(key.which == 38){
        key.preventDefault();
        pagescrolled = $('#versecontainer')[0].scrollTop;
        
        if(pagescrolled === scrolled && pagescrolled >=30){
            pagescrolled -= 30;
            $('#versecontainer').scrollTop(pagescrolled);
            scrolled = $('#versecontainer')[0].scrollTop;
        }
    }
    else{
	    var updatetransflag = false;
	    switch(key.which){
	       case 69:
	            key.preventDefault();
	            if($('#english').prop('checked'))
	                $('#english').prop('checked',false);
	            else
	                $('#english').prop('checked',true);
	            updatetransflag = true;
	        break;
	        case 65:
	            key.preventDefault();
	            if($('#arabic').prop('checked'))
	                $('#arabic').prop('checked',false);
	            else
	                $('#arabic').prop('checked',true);
	            updatetransflag = true;
	        break;
	        case 77:
	            key.preventDefault();
	            if($('#mqs').prop('checked'))
	                $('#mqs').prop('checked',false);
	            else
	                $('#mqs').prop('checked',true);
	            updatetransflag = true;
	        break;
	        case 73:
	            key.preventDefault();
	            if($('#indonesian').prop('checked'))
	                $('#indonesian').prop('checked',false);
	            else
	                $('#indonesian').prop('checked',true);
	            updatetransflag = true;
	        break;
	        case 84:
	            key.preventDefault();
	            if($('#jalalayn').prop('checked'))
	                $('#jalalayn').prop('checked',false);
	            else
	                $('#jalalayn').prop('checked',true);
	            
	            updatetransflag = true;
	        break;
	    }
	    if(updatetransflag)
	        updatetranslation();
    }
}
function startrandomsura(){
    endplaying();
    if(searchpage){
        resetsearchpage();
        currentsura = 0;
    }
    $.ajax({
        url:'./',
        type:'POST',
        data:{app:appname,p:'ajax',a:'randomsura'}
    }).done(function(msg){
        msg = JSON.parse(msg);
        $('#svnum').val(parseInt(msg.verse));
        $('#vppnum').val(1);
        startrandomsuracb.displaysuracb = true;
        startrandomsuracb.randomaya = parseInt(msg.verse);
        displaysura(parseInt(msg.suraid),false);
    });
}
var startrandomsuracb = {
    displaysuracb:false,
    randomaya:false,
    playrandom:function(){
        startrandomsuracb.displaysuracb = false;
        $('#audiostart').val(startrandomsuracb.randomaya);
        $('#audioend').val(startrandomsuracb.randomaya);
        playrecital();   
    }
};
function updateversesett(){
	$('#updateversesetting').on('click',function(){
	    updateversesettfn();
	});
}
function updateversesettfn(){
	if(searchpage){
		resetsearchpage();
	}
	startfrom       = Math.min( (qtrans[currentsura].length-1) ,parseInt($('#svnum').val()));
	verseperpage    = Math.min(5,parseInt($('#vppnum').val()));
            $('#vppnum').val(verseperpage);
            $('#svnum').val(startfrom);
	writepage();
}

$('#updatetrans').on('click',function(){
    updatetranslation();
});
function updatetranslation(){
	newlang = Array();
	$.each($('.translang'), function(i,v){
		if($(v).prop('checked')){
			newlang[newlang.length] = $.inArray($(v).attr('id'), qlangmap);
		}
	});
	
	/* compare w current */
	startnewlang = false;
	if(currentlang.length === newlang.length){
		$.each(currentlang, function(i,v){
			if(v !== newlang[i]){
				startnewlang = true;
				return false;
			}
		});	
	}
	else{
		startnewlang = true;
	}
	
	if(startnewlang){
		if(startfrom === (verseperpage+1) || startfrom <= verseperpage)
			startfrom = 1;
		else{
			if(startfrom === qtrans[currentsura].length && startfrom % verseperpage > 1)
				startfrom +=  (verseperpage -  ((qtrans[currentsura].length) % verseperpage)) +1;

			startfrom  = startfrom  - (verseperpage);				
		}

		currentlang = Array();
		currentlang = $.merge([], newlang);	

		getlang = Array();
		$.each(newlang,function(i,v){
			if(typeof(qtrans[currentsura][1][v]) === 'undefined'){
				getlang[getlang.length] = v;
			}
		});

		if(getlang.length > 0){
			getLang(getpostlang(getlang), currentsura);
		}
		else{
			if(searchpage){
				searchkey();
				return;
			}
			writepage();
		}
	}
}

function writeresult(sn,an,lang,dispversenum,vt,key){
    var langclass = 'translation';
    var versenum = '';
    langclass += ' '+qlangmap[lang];

    if(dispversenum){
            versenum = '<span class="versenum" id="'+ an +'_'+ sn +'">'+an+'</span>';
    }
    vt = highlightkeys(key,vt);
    $('#verselist').append('<li class="'+langclass+'"><span class="langcolor"></span>'+vt+versenum+'</li>');
}
function highlightkeys(key,verse){
	var multiplefindings = [];
	multiplefindings[0] = 0;
	var subjectstr;
	
	while(multiplefindings[0] !== false){
		if(multiplefindings.length == 1)
			subjectstr = verse;
		else{
			subjectstr = verse.substr(multiplefindings[multiplefindings.length-1]+key.length);
		}
			
		tempfound = subjectstr.toLowerCase().indexOf(key);
		var akey = false;
		if(tempfound !== -1){
			if( tempfound === 0 ||  subjectstr.length === (tempfound+key.length+1) || $.inArray(subjectstr[tempfound+key.length],allowedcompany) !== -1 ){
				if( tempfound === 0 || (tempfound > 0 && $.inArray(subjectstr[tempfound-1],allowedcompany) !== -1 )  ){
				    akey = true;
				    var tempverse1 = multiplefindings.length ==1 ?  verse.substr(0,(multiplefindings[multiplefindings.length-1]+tempfound)) : verse.substr(0,(multiplefindings[multiplefindings.length-1]+tempfound+key.length));
				    var tempverse2 = subjectstr.substr(tempfound);
				    
				    tempverse2 = '<span class="searchkey">'+tempverse2.substr(0,key.length)+'</span>'+tempverse2.substr(key.length);
				    verse = tempverse1+tempverse2;
				}
			}
			
			if(multiplefindings.length == 1){
			    if(akey){
				    multiplefindings[multiplefindings.length] = multiplefindings[multiplefindings.length-1] + tempfound+31;
			    }
				else
				    multiplefindings[multiplefindings.length] = multiplefindings[multiplefindings.length-1] + tempfound;
			}
			else{
			    if(akey)
				    multiplefindings[multiplefindings.length] = multiplefindings[multiplefindings.length-1] + tempfound+key.length+31;
				else
				    multiplefindings[multiplefindings.length] = multiplefindings[multiplefindings.length-1] + tempfound+key.length;
			}
		}
		else{
			multiplefindings[0] = false;
		}
	}
	return verse;
}

function writeresults(key,suraid){
    showloadingnotif();
    $('#verselist').html('');
    var keyresult       = [];
    var currentverse    = 0;
    var suranum         = 0;
    var surasum         = 0;
    var versesum        = 0;
    var langexist       = [];
    
    if(suraid === 0){
        luplimit = [];
        maps = getallmap(key);
        $.each(maps, function(i,v){
            v['indexes'].sort(function(a,v){
                result = searchresult[key][a]['versenum'] - searchresult[key][v]['versenum'];
                return result;
            });
            $.each(v['indexes'], function(yi,yv){
               luplimit[luplimit.length] = searchresult[key][yv]; 
            });
        });
    }
    else{
        luplimit = [];
        map = getmap(suraid,key);
        map.sort(function(a,v){
            result = searchresult[key][a]['versenum'] - searchresult[key][v]['versenum'];
            return result;
        });
        $.each(map, function(yi,yv){
            luplimit[luplimit.length] = searchresult[key][yv];
        });
    }
    
    $.each(luplimit, function(ii,vv){
        keyresult = vv;
            if( $.inArray(keyresult['lang'], currentlang)  !== -1){
                if(suranum !== keyresult['suranum']){
                    $('#verselist').append('<li class="suranamehead">'+ suranames[keyresult['suranum']].substr(0,  suranames[keyresult['suranum']].indexOf('<span class="numofverse">')) +'</li>');   
                    suranum = keyresult['suranum'];
                    surasum++;
                }
                
                if(currentverse !== keyresult['versenum']){
                    if(currentverse !== 0){
                        $('#verselist').append('<li class="verseseparator"></li>');   
                    }
                    writeresult(keyresult['suranum'], keyresult['versenum'],keyresult['lang'],true,keyresult['verse'],key);
                    currentverse = keyresult['versenum'];
                    versesum++;
                }
                else{
                    writeresult(keyresult['suranum'], keyresult['versenum'],keyresult['lang'],false,keyresult['verse'],key);
                }
                if($.inArray(keyresult['lang'],langexist) === -1)
                    langexist[langexist.length] = keyresult['lang'];
            }
    });
    if(surasum === 0){
        emptysearch();
    }
    else{
        if(suraid === 0)
            $('#searchdesctext').html('"'+key+'" found in '+versesum+' verse of '+ surasum +' sura '+getlangtext(langexist));    
        else
            $('#searchdesctext').html('"'+key+'" found in '+versesum+' verse '+getlangtext(langexist)); 
            
        getscrolledsearchpage(langexist,key);
    }
    hideloadingnotif();
}
function getscrolledsearchpage(langexist,key){
    if(typeof scrolledsearchpage.cidx === 'undefined'){
        scrolledsearchpage.cidx = 0;
        
        scrolledsearchpage.scroll = [];
        scrolledsearchpage.scroll[scrolledsearchpage.cidx] = [];
        scrolledsearchpage.scroll[scrolledsearchpage.cidx].scrolled = 0;
        scrolledsearchpage.scroll[scrolledsearchpage.cidx].id = [langexist,key];
        
        $('#verselist').scrollTop(scrolledsearchpage.scroll[scrolledsearchpage.cidx].scrolled);
        return;
    }
    var scolledspidx = false;
    var langcompare = 0;
    for(var i=0;i<scrolledsearchpage.scroll.length;i++){
        if(scrolledsearchpage.scroll[i].id[1]==key){
            if(scrolledsearchpage.scroll[i].id[0].length == langexist.length){
                langcompare = 0;
                for(var ii=0;scrolledsearchpage.scroll[i].id[0].length;ii++){
                    if($.inArray(scrolledsearchpage.scroll[i].id[0][ii],langexist) === -1){
                        break;
                    }
                    else{
                        langcompare++;
                    }
                }
                if(langcompare == langexist.length){
                    scolledspidx = i;
                    break;
                }
            }
        }
    }
    if(scolledspidx!==false){
        scrolledsearchpage.cidx = scolledspidx;
        $('#versecontainer').scrollTop(scrolledsearchpage.scroll[scrolledsearchpage.cidx].scrolled);
    }
    else{
        scrolledsearchpage.cidx = scrolledsearchpage.scroll.length;
        
        scrolledsearchpage.scroll[scrolledsearchpage.cidx] = [];
        scrolledsearchpage.scroll[scrolledsearchpage.cidx].scrolled = 0;
        scrolledsearchpage.scroll[scrolledsearchpage.cidx].id = [langexist,key];
        
        $('#versecontainer').scrollTop(scrolledsearchpage.scroll[scrolledsearchpage.cidx].scrolled);
    }
}
function getsearch(){
    $('#getsearch').on('click',searchkey);
}

function searchkey(){
    var key         = $('#searchkeyword').val().toLowerCase();
    var incurrent 	= $('#searchincurrent').prop('checked');
    var found       = true;
    var keyfound 	= false;
    var mapidx      = 0;

    if(key === 'keyword')
        return;
    
    if(incurrent){
        if(typeof(searchresult[key]) === 'undefined'){
            searchresult[key] = [];
            
            searchresultmap[key]                    = [];
            searchresultmap[key][mapidx]            = [];
            searchresultmap[key][mapidx]['indexes'] = [];
            searchresultmap[key][mapidx]['suraid']  = currentsura;
            searchresultmap[key][mapidx]['keylang'] = [];

            found = false;
            searchlang = $.merge([],currentlang);
        }
        else{
            //compare lang;
            searchlang = [];
            mapidx = getsearchresmapidx(currentsura,key);
            
            $.each(currentlang,function(i,v){
                if($.inArray(v, searchresultmap[key][mapidx]['keylang']) === -1){
                        searchlang[searchlang.length] = v;
                }
            });
             
            if(searchlang.length >0){
                keyfound = true;
                found = false;
            }
            else{
                if(getmaplength(currentsura,key) > 0)
                    keyfound = true;
            }
        }
        
        if(!found){
            searchresultmap[key][mapidx]['keylang'] = $.merge(searchresultmap[key][mapidx]['keylang'],searchlang);
            $.each(qtrans[currentsura],function(i,v){
                if(i === 0){return;}
                $.each(searchlang,function(ii,vv){
					var multiplefindings = [];
					multiplefindings[0] = 0;
					
					while(multiplefindings[0] !== false){
						if(multiplefindings.length == 1)
							var subjectstr = v[vv];
						else
							var subjectstr = v[vv].substr(multiplefindings[multiplefindings.length-1]+key.length);
							
						tempfound = subjectstr.toLowerCase().indexOf(key);
						if(tempfound !== -1){							
							if( tempfound === 0 ||  subjectstr.length === (tempfound+key.length+1) || $.inArray(subjectstr[tempfound+key.length],allowedcompany) !== -1 ){
								if( tempfound === 0 || (tempfound > 0 && $.inArray(subjectstr[tempfound-1],allowedcompany) !== -1 )  ){
									idx = searchresult[key].length;
									
									searchresultmap[key][mapidx]['indexes'][searchresultmap[key][mapidx]['indexes'].length] = idx;
									
									searchresult[key][idx] = [];
									searchresult[key][idx]['versenum'] = i;
									searchresult[key][idx]['lang'] = vv;
									searchresult[key][idx]['verse'] = qtrans[currentsura][i][vv];
									searchresult[key][idx]['suranum'] = currentsura;
									keyfound = true;
									multiplefindings[0] = false;
								}
							}
							
							if(multiplefindings.length == 1)
								multiplefindings[multiplefindings.length] = multiplefindings[multiplefindings.length-1] + tempfound;
							else
								multiplefindings[multiplefindings.length] = multiplefindings[multiplefindings.length-1] + tempfound+key.length;
						}
						else
							multiplefindings[0] = false;
					}
                });
            });
        }	
        
        if(keyfound){
            setsearchpage();
            writeresults(key,currentsura);
            searchverse();
        }
        else{
            emptysearch();
        }
    }
    else{
        if(typeof(searchresult[key]) === 'undefined' || typeof searchresult[key][mapidx] === 'undefined'){
            searchresult[key] = [];
            
            searchresultmap[key]                    = [];
            searchresultmap[key][mapidx]            = [];
            searchresultmap[key][mapidx]['indexes'] = [];
            searchresultmap[key][mapidx]['suraid']  = currentsura;
            searchresultmap[key][mapidx]['keylang'] = [];

            found = false;
            searchlang = $.merge([],currentlang);
        }
        else{
            //compare lang
            searchlang              = [];
            mapidx                  = getsearchresmapidx(0,key);
            
            if(searchresultmap[key][mapidx]['keylang'].length === 0){
                searchlang = currentlang;
            }
            else{
                $.each(currentlang,function(i,v){
                    if($.inArray(v, searchresultmap[key][mapidx]['keylang']) === -1){
                        searchlang[searchlang.length] = v;
                    }
                }); 
            }
            
            if(searchlang.length >0){
                searchresultmap[key][mapidx]['keylang'] = $.merge(searchresultmap[key][mapidx]['keylang'], searchlang);
                found = false;
            }
            else{
                if(searchresult[key].length > 0)
                    keyfound = true;
            }
        }
        
        if(!found){
            showloadingnotif();
            $.ajax({
                url:"./",
				data:{app:appname,p:'ajax',a:'key',d:{searchlang:getpostlang(searchlang),key:key}},
                type:"POST"
            }).done(function(msg){
                if(msg === '0'){
                    emptysearch();
                }
                else{
                    keyfound = true;
                    searchres = $.parseJSON(msg);
                    $.each(searchres, function(i,v){
                        i = parseInt(i);
                        newlang = [];
                        mapidx = getsearchresmapidx(i,key);
                        searchedandfound = false;
                        if( searchresultmap[key][mapidx]['keylang'].length ){
                            searchedandfound = true;
                            $.each(searchlang, function(si,sv){
                               if($.inArray(sv,searchresultmap[key][mapidx]['keylang']) === -1){
                                   searchedandfound = false;
                                   newlang[newlang.length] = sv;
                               } 
                            });
                        }
                        else{
                            newlang = searchlang;
                        }
                        
                        if(!searchedandfound){
                            searchresultmap[key][mapidx]['keylang'] = $.merge(searchresultmap[key][mapidx]['keylang'],newlang);
                            $.each(v, function(ii,vv){
                                ii = parseInt(ii);
                                $.each(vv, function(iii,vvv){
                                    iii = parseInt(iii);
                                    if($.inArray(iii, newlang) !== -1){
                                       idx = searchresult[key].length;
                                       if(typeof searchresultmap[key][mapidx]['indexes'] === 'undefined'){
                                           searchresultmap[key][mapidx]['indexes'] = [];
                                       }
                                       searchresultmap[key][mapidx]['indexes'][searchresultmap[key][mapidx]['indexes'].length] = idx;

                                       searchresult[key][idx] = [];
                                       searchresult[key][idx]['versenum'] = ii;
                                       searchresult[key][idx]['lang'] = iii;
                                       searchresult[key][idx]['verse'] = vvv;
                                       searchresult[key][idx]['suranum'] = i;
                                    }
                                });
                            });
                        }
                    });
                    setsearchpage();
                    writeresults(key,0);
                    searchverse();
                }
                hideloadingnotif();
            });
        }
        else{
            if(keyfound){
                setsearchpage();
                writeresults(key,0);
                searchverse();
            }
            else{
                emptysearch();
            }
        }
    }
}
function getmaplength(thesura,thekey){
    mapidx = getsearchresmapidx(thesura,thekey);
    return searchresultmap[thekey][mapidx]['indexes'].length;
}
function getmap(thesura,thekey){
    mapidx = getsearchresmapidx(thesura,thekey);
    return searchresultmap[thekey][mapidx]['indexes'];
}
function getallmap(key){
    searchresultmap[key].sort(function(a,v){
        return a['suraid'] - v['suraid'];
    });
    return searchresultmap[key];
}
function getsearchresmapidx(thesura,thekey){
    theidx = false;
    $.each(searchresultmap[thekey], function(ui,uv){
        if(uv['suraid'] === thesura){
            theidx =  ui;
        }
    });
    if(theidx === false){
        theidx = searchresultmap[thekey].length;
        searchresultmap[thekey][theidx] = [];
        searchresultmap[thekey][theidx]['suraid']   = thesura;
        searchresultmap[thekey][theidx]['keylang']  = [];
        searchresultmap[thekey][theidx]['indexes']  = [];
    }
    return theidx;
}
function emptysearch(){
    setsearchpage();
    $('#searchdesctext').html('');
    $('#verselist').html('<li class="emptysearch">None Found</li>');
}
function searchverse(){
    $('.versenum').on('click',function(){
        var vnu         = parseInt($(this).html());
        var csura 	= this.id.substr(this.id.indexOf('_')+1);
        currentsura     = parseInt(csura);
        startfrom       = vnu;
        
        $('#svnum').val(vnu);
        resetsearchpage();
        
        if(typeof(qtrans[currentsura]) === 'undefined'){
            initSura(currentsura, getpostlang(currentlang));
        }
        else{
            newlang = [];
            availlang = qtrans[currentsura][0];
            $.each(currentlang, function(oi,ov){
                if( $.inArray(ov,availlang) === -1){
                    newlang[newlang.length] = ov;
                }
            });
            
            if(newlang.length){
                initSura(currentsura,getpostlang(newlang));
            }
            else{
                writepage();
                $('.suralistitem').removeClass('selected');
		        $('#suranum_'+currentsura).addClass('selected');
            }
        }
    });
}
function setsearchpage(){
    $('#verselist').addClass('searchmode');
    $('#verselist').html('');
    $.each(qlangmap,function(i,v){
            $('#'+v+'_opt').addClass('searchmode');
    });
    searchpage = true;
    $('.navi').addClass('hide');
    $('#searchdesc').addClass('show');
}
function resetsearchpage(){
    scrolledsearchpage.scroll[scrolledsearchpage.cidx].scrolled = $('#versecontainer')[0].scrollTop;
    $('#verselist').removeClass('searchmode');
    $.each(qlangmap,function(i,v){
            $('#'+v+'_opt').removeClass('searchmode');
    });
    searchpage = false;
    $('#searchdesctext').html('');
    $('.navi').removeClass('hide');
    $('#searchdesc').removeClass('show');
}

function showloadingnotif(){
    if(!loading){
        loading = true;
        $('#loadingnotif').css('display','block');
    }
        
}
function hideloadingnotif(){
    if(loading){
        loading = false;
        $('#loadingnotif').css('display','none');
    }
}
var localstorage = false;
function getLocalStorage(){
    if (typeof localStorage == "object"){
        localstorage =  localStorage;
    } else if (typeof globalStorage == "object"){
        localstorage = globalStorage[location.host];
    } else {
        localstorage = false;
    }
    userdata.init();
}

var userdata = {
    init:function(){
        if(localstorage === false){
            return;
        }
        var temp = localstorage.getItem('asmaulhusnascrolled');
        asmaulhusnascrolled = (temp == '' || temp == null || temp == false || temp == 'null' || temp == 'undefined') ? 0 : parseInt(temp);
    },
    update:function(varname){
        switch(varname){
            case 'asmaulhusnascrolled':
                localstorage.setItem('asmaulhusnascrolled',asmaulhusnascrolled);
            break;
            default:
            break;
        }
    }
};