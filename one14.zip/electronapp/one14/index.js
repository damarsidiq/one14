const electron = require('electron')
const app = electron.app
const BrowserWindow = electron.BrowserWindow

let win

function draw() {
    win = new BrowserWindow({icon:'/media/damarsidiq/pic/icons/kalam.png', width: 1200, height: 700, resizable: true,y:0,x:83  });
    win.webContents.session.clearCache(function(){});
    win.setTitle('One14');
    //win.setMenu(null);
    win.setMenuBarVisibility(false);
    win.isMaximizable(true);
    win.isResizable(true);
    win.setAlwaysOnTop(false, "floating");
    win.loadURL('http://pxpedia/pxpedia/?app=one14&d[electronapp]=1');
    win.show();
}
app.on('ready', draw)
