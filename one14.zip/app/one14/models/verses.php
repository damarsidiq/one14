<?php 
Class Verses extends Model{
	function __construct(){
		parent::__construct('verses');
	}
	
	public function getrandomdesc($id){
	    $rec = $this->getrecord(array('id'=>$id));
	    return array('suraid'=>$rec['sura'],'verse'=>$rec['versenum']);
	}
}
?>
