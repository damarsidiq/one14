<?php 
Class Blogpdf extends Model{
    var $pdfheader;
    var $pdfcontent;
    
	function __construct(){
		parent::__construct();
        $this->pdfheader    = '<style type="text/css">
            <!--
                html,body{font-family:Arial;}
                a{color:#949494;text-decoration: none;font-size: 34px;}
                img{display: block;margin: auto;max-width: 100%;}
                li{padding:0px;margin:5px 0px;}
                h2{margin: 0px;}
                p{display: block;margin-bottom: 1em;margin-top: 1em;}
                ul{padding:0px 0px 0px 40px;margin:0px;}
                .verseseparator{border-bottom: 1px dotted #999999;margin: 0;height: 0px;padding: 0px;}
                .verselist{background: #ffffff;padding: 12px 15px 2px;list-style: outside none none;margin: 0px;font-size: 15px;text-align: right;display: block;border-bottom: 1px solid #EFEFEF;}
                .verselist.lastlang{border-bottom:none;margin-bottom:5px;padding-bottom:30px;}
                .verselist.arabic{font-family:"pdms";direction:rtl;font-size: 44px;line-height: 65px;min-height: 65px;}
                .verselist.versenum{float: left;display:inline-block;font-size: 12px;border-radius: 100%;border: 1px solid #c7c7c7;color: #000000;background: #efefef;width: 20px;height: 20px;line-height: 10px;text-align: center;}
            -->
            </style>';
        
        $this->undecoded = array('&apos;','&lt;','&gt;');
        $this->undecodedreplacement = array('','(',')');
        $this->pdfcontent = '';
	}
	public function cleanstr($str,$orientation,$fiximagesize){
         //return str_replace(array('<figcaption','figcaption>','<figure','figure>','<section','section>','<aside','aside>'),array('<p','p>','<p','p>','<div','div>','<div','div>'),htmlspecialchars_decode(str_replace($this->undecoded,$this->undecodedreplacement,$str),ENT_QUOTES));
         $cs = htmlspecialchars_decode(str_replace($this->undecoded,$this->undecodedreplacement,$str),ENT_QUOTES);

        if(strpos($cs,'<img') === false){
          return $cs;
        }
         $cs = explode('<img',$cs);


         $a4 = $orientation == 'landscape' ? array('72'=>array(595,842),'96'=>array(794,1123),'150'=>array(1240,1754),'300'=>array(2480,3508)) : array('72'=>array(842,595),'96'=>array(1123,794),'150'=>array(1754,1240),'300'=>array(3508,2480));
         foreach ($cs as $l=>$value) {
             if($value =='')
                continue;
                
                
            
             if($l >0){
                 $i = explode('src="',$value);
                 $prefsize = explode('>',$value)[0];
                 if(strpos($prefsize,'width=') !==false && strpos($prefsize,'height=') !==false && $fiximagesize){
                     $sizesx = explode('width="',$prefsize);
                     $width = explode('"',$sizesx[1])[0];
                     
                     $sizesx = explode('height="',$prefsize);
                     $height = explode('"',$sizesx[1])[0];
                     
                     $x = explode('>',$value);
                     $marginleft= $width<($a4['96'][1]-90) ? ((($a4['96'][1]-90)-$width)/2) : 0;
                     $width = $marginleft == 0 ? ($a4['96'][1]-90) : $width;
                     $height= min($height,($a4['96'][0]-90));
                     
                     
                     $x[0] = ' style="height:'.$height.'px;margin:auto;margin-left:'.$marginleft.'px;width:'.$width.'px;" '.$x[0];
                     $x[1] = '</div>'.$x[1];
                     $value = implode('>',$x);
        
                    $cs[$l] = $value;
        
                    $value = '<div style="page-break-before:avoid;page-break-after:auto;clear:both;width:100%;text-align:center;height:'.$height.'px;">';
                    $cs[$l-1] = $cs[$l-1].$value;
                    
                    continue;
                 }
                 
                 $i = explode('"',$i[1])[0];
                 list($width,$height) = getimagesize($i);

                 $x = explode('>',$value);
                 $marginleft= $width<($a4['96'][1]-90) ? ((($a4['96'][1]-90)-$width)/2) : 0;
                 $width = $marginleft == 0 ? ($a4['96'][1]-90) : $width;
                 $height= min($height,($a4['96'][0]-90));
                 
                 
                 $x[0] = ' style="height:'.$height.'px;margin:auto;margin-left:'.$marginleft.'px;width:'.$width.'px;" '.$x[0];
                 $x[1] = '</div>'.$x[1];
                 $value = implode('>',$x);

                $cs[$l] = $value;

                $value = '<div style="page-break-before:avoid;page-break-after:auto;clear:both;width:100%;text-align:center;height:'.$height.'px;">';
                $cs[$l-1] = $cs[$l-1].$value;
             }
         }
         $cs = implode('<img',$cs);
         return $cs;
    }
	 public function outputdompdf($orientation,$fiximagesize){
	    require_once Pxpedia::getConfig('resources') . 'vendor/vendor/autoload.php';
	    
	    $mpdf = new Mpdf\Mpdf();
	    $mpdf->autoScriptToLang = true;
        $mpdf->baseScript = 1;
        $mpdf->autoVietnamese = true;
        $mpdf->autoArabic = true;
        $mpdf->autoLangToFont = true;

        //$stylesheet = file_get_contents('http://pxpedia/pxpedia/views/one14/default/styles/fontface.css');
        //$mpdf->WriteHTML($stylesheet,1);
        
        
        $mpdf->WriteHTML($this->pdfheader.$this->pdfcontent);
        $mpdf->defaultCSS['BODY']['FONT-FAMILY'] = 'franklin';
        //echo print_r($mpdf->defaultCSS,true);exit();
        $mpdf->Output();
        exit();
        
        require_once(Pxpedia::getConfig('resources').'html2pdf/html2pdf.class.php');
	    try{
            $html2pdf = new HTML2PDF('P', 'A3', 'en', true, 'UTF-8', array(17, 0, 17, 0),false);
            $html2pdf->addFont('aealarabiya', '', 'aealarabiya.php');
            $html2pdf->pdf->SetDisplayMode('fullpage');
            $html2pdf->writeHTML($this->pdfheader.$this->pdfcontent, false);
           //echo print_R($html2pdf->parsingHtml,true);exit();
            //echo $html2pdf->pdf->getBuffer();exit();
            //echo $this->pdfheader.$this->pdfcontent;exit();
            $this->pdfcontent = '';

            $html2pdf->Output('NOW.NEWS-'. date('l, F jS Y',time()) .'.pdf','I');
        }
        catch(HTML2PDF_exception $e){
            echo $e;
            exit();
        }
        
        exit();
        
        //echo $this->pdfheader.$this->pdfcontent;
        //exit();
        
        require_once Pxpedia::getConfig('resources').'dompdf/lib/html5lib/Parser.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-font-lib/src/FontLib/Autoloader.php';
        require_once Pxpedia::getConfig('resources').'dompdf/lib/php-svg-lib/src/autoload.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Autoloader.php';


        require_once Pxpedia::getConfig('resources').'dompdf/src/CanvasFactory.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Options.php';
        require_once Pxpedia::getConfig('resources').'dompdf/src/Dompdf.php';
        Dompdf\Autoloader::register();

        $dompdf = new Dompdf\Dompdf();
        
        $this->pdfcontent = $this->cleanstr($this->pdfcontent,$orientation,$fiximagesize);
        
        $dompdf->loadHtml($this->pdfheader.$this->pdfcontent);
        $dompdf->setPaper('A4', $orientation);
        $dompdf->render();

        //echo $this->pdfheader.$this->pdfcontent;
        $this->pdfcontent = '';
        //exit();

        $dompdf->stream();
    }
}
?>
