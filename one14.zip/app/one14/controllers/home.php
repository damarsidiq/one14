<?php

Class Home extends Controller{
    function __construct() {
        parent::__construct();
    }
    public function pageInit($data=null,$view='largehome'){
        $this->setPagevar('mobile','');
		if(Pxpedia::isMobile()){
		    $this->setPagevar('mobile','mobile');
		    $this->setPagevar('pagesrc',array());
			$this->addheadfootsrc(array('mobilecss'=>App::getConfig('appviews').'/styles/mobile.css'),array('jquery'=>'res/jquery/jquery-1.9.1.min.js','appjs'=>'res/one14/app.min.js'));
			$view = 'home';
		}
		else{
			$sura = $this->db->getRows('sura');
			$suralist = '';
			foreach($sura as $k=>$v ){
				$fname = explode(';',$v['name']);
				$frname = '<span class="surname">'. $v['id'] .'.'.$fname[1].'</span><span class="engname">&nbsp;('. $fname[0] .')</span>';
				$suralist  .= '<li class="suralistitem" id="suranum_'. $v['id']  .'">'.  $frname  .'<span class="numofverse">'. $v['versecount'] .'</span></li>';
			}
			
			$this->setPagevar('suralist',$suralist);
		}
		return $view;
    }
}