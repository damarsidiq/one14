<?php
Class Ajax extends Controller{
    var $langmap = array();

    function __construct(){
        parent::__construct();
        $this->langmap[0] = 'indonesian';
        $this->langmap[1] = 'english';
        $this->langmap[2] = 'jalalayn';
        $this->langmap[3] = 'mqs';
        $this->langmap[4] = 'arabic';
    }
    public function suratopdf($suraid){
        $q =  'SELECT * FROM verses where sura='. $suraid;
        $res = $this->db->fetchQueryResult($this->db->query( $q),true);
        $data = array();
        $this->model('blogpdf')->pdfcontent = '';
        
        foreach($res as $k=> $n){
            $data[$n['versenum']][$n['lang']] = ($n['verse']);
        }
        
        foreach($data as $k=>$v){
            $this->model('blogpdf')->pdfcontent .= '<div class="verselist arabic" lang="ara" style="direction:rtl;font-size: 44px;line-height: 65px;min-height: 65px;">'.$v[4].'<div class="verselist versenum" style="float:left;display:inline-block;font-size: 12px;border-radius: 100%;border: 1px solid #c7c7c7;color: #000000;background: #efefef;width: 20px;height: 20px;line-height: 10px;text-align: center;">'.$k.'</div></div>';
            $this->model('blogpdf')->pdfcontent .= '<div class="verselist">'.$v[1].'</div>';
            $this->model('blogpdf')->pdfcontent .= '<div class="verselist">'.$v[0].'</div>';
            $this->model('blogpdf')->pdfcontent .= '<div class="verselist">'.$v[3].'</div>';
            $this->model('blogpdf')->pdfcontent .= '<div class="verselist lastlang">'.$v[2].'</div>';
            
            $this->model('blogpdf')->pdfcontent .= '<div class="verseseparator"></div>';
        }
    }
    public function pdfsura($data){
        /*
        $a = file_get_contents('http://pxpedia/pxpedia/views/one14/default/styles/PDMS_Saleem_QuranFont-signed.ttf');
        echo base64_encode($a);
        echo '-esse-';
        exit();
        */
        $this->suratopdf($data['suraid']);
        //echo $this->model('blogpdf')->pdfheader.$this->model('blogpdf')->pdfcontent;
        $this->model('blogpdf')->outputdompdf('portrait',false);
        return 'plain';
    }
    public function randomsura($data){
        $random = random_int(1,6236);
        $desc = $this->model('verses')->getrandomdesc($random);
        $this->setPagevar('response',$desc);
        return 'ajax';
    }
    public function sura($data){
        $langs = $data['lang'];
        $sura = $data['sura'];
    
        $q =  'SELECT * FROM verses where sura='. $sura .' and lang IN('. $langs .')';
        $res = $this->db->fetchQueryResult($this->db->query( $q),true);
        $data = array();
    
        foreach($res as $k=> $n){
                $data[$n['sura']][$n['versenum']][$n['lang']] = ($n['verse']);
        }
        $this->setPagevar('response',$data);
    }
    
    public function reqlang($data){
        $langs = $data['reqlang'];
        $sura = $data['suraid'];
    
        $q =  'SELECT * FROM verses where sura='. $sura .' and lang IN('. $langs .')';
        $res = $this->db->fetchQueryResult($this->db->query( $q),true);
        $data = array();
    
        foreach($res as $k=> $n){
            $data[$n['sura']][$n['versenum']][$n['lang']] = ($n['verse']);
        }
        $this->setPagevar('response',$data);
    }
    
    public function key($data){
        $key        = $data['key'];
        $searchlang = $data['searchlang'];
        
        $q              = 'select * from verses where lang in('. $searchlang .') and verse like "%'. $key .'%"';
        $res            = $this->db->fetchQueryResult($this->db->query( $q),true);
        if(count($res) === 0){
            echo '0';
            exit();
        }
        $data               = array();
        $allowedcompany     = array(' ','(',')','.',',','-', '"', "'",'!', ':', ';','?','-');
        
        foreach($res as $k=>$n){
            $multiplefindings 		= [];
            $multiplefindings[0] 	= 0;
            
            while($multiplefindings[0] !== false){
                if(count($multiplefindings) == 1)
                    $subjectstr = $n['verse'];
                else
                    $subjectstr = substr($n['verse'],$multiplefindings[count($multiplefindings)-1]+strlen($key));
                
                $loca = stripos($subjectstr, $key);
                
                if($loca !== false){
                    if( $loca === 0 ||  strlen($subjectstr) === ($loca+strlen($key)+1) || in_array($subjectstr[$loca+strlen($key)],$allowedcompany) ){
    					if( $loca === 0 || ($loca > 0 && in_array($subjectstr[$loca-1],$allowedcompany) )  ){
    					    $data[$n['sura']][$n['versenum']][$n['lang']] = ($n['verse']);
                            $multiplefindings[0] = false;
    					}
                    }
                	
                	if(count($multiplefindings) == 1){
                        $multiplefindings[] = $multiplefindings[count($multiplefindings)-1] + $loca;
                    }
                    else{
                        $multiplefindings[] = $multiplefindings[count($multiplefindings)-1] + $loca + strlen($key);
                    }
                }
                else{
                    $multiplefindings[0] = false;
                    break;
                }
            }
        }
        $this->setPagevar('response',$data);
    }
    
    public function hadith($data){
        $data = array();
        $query = 'select * from book';
        $books = $this->db->fetchQueryResult($this->db->query( $query),true);
        $count = 0;
        foreach($books as $k=> $b){
            $count++;
            $data[$b['imam']][$count]['title'] = $b['title'];
            $data[$b['imam']][$count]['id'] = $b['id'];
        }
        $this->setPagevar('response',$data);
    }
    
    public function bookreq($data){
        $bookreq = $data['bookreq'];
        $data = array();
        $index = 0;
        $chap = $this->db->fetchQueryResult($this->db->query('select * from chapter where book = '.$bookreq.' order by numbering asc'),true);
        $htext = $this->db->fetchQueryResult($this->db->query('select * from hadith where book = '.$bookreq.' order by numbering asc'),true);
        
        foreach($chap as $key=>$chapters){
            $data[$index]['id'] = $chapters['id'];
            $data[$index]['title'] = $chapters['title'];
            $data[$index]['book'] = $chapters['book'];
            $data[$index]['numbering'] = $chapters['numbering']; 
            $data[$index]['hadithtext'] = array();
            $index++;
        }
        $cc = -1;
        foreach($htext as $key=>$ht){
            if($cc === -1 || $data[$cc]['numbering'] !== $ht['chapter']){
                foreach($data as $di=>$dv){
                    if($dv['numbering'] === $ht['chapter']){
                        $cc = $di;
                    }
                }
            }
            $htix = count($data[$cc]['hadithtext']);
            $data[$cc]['hadithtext'][$htix] = $ht;
        }
        $this->setPagevar('response',$data);
    }
    
    public function hadithkey($data){
        $key = $data['hadithkey'];
        $imam = $data['imam'];
        $book = $data['book'];
        $data = array();
    
        if($book > 0){
            $q = 'select h.*,c.title from hadith h,chapter c where h.book = '. $book .' and (h.hadith like "%'. $key .'%" or (h.notes !="" and h.notes like "%'.  $key .'%")) and (h.chapter = c.numbering and h.book = c.book)';
        }
        else{
            $q = 'select h.*,c.title from hadith h,chapter c where h.book in(select id from book where imam = '. $imam .') and (h.hadith like "%'. $key .'%" or (h.notes !="" and h.notes like "%'.  $key .'%")) and (h.chapter = c.numbering and h.book = c.book)';
        }
        $searchresult = $this->db->fetchQueryResult($this->db->query($q),true);
        foreach($searchresult as $key=>$searchres){
            $inx = count($data);
            $data[$inx]['chap'] = $searchres['title'];
            $data[$inx]['book'] = $searchres['book'];
            $data[$inx]['notes'] = $searchres['notes'];
            $data[$inx]['hadith'] = $searchres['hadith'];
        }
        
        $this->setPagevar('response',$data);
    }
    
    
}


?>