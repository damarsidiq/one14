<?php

Class Transaudio extends Controller{
    var $uploadfolder;
    var $rawf;
    var $newfold;
    function __construct() {
        parent::__construct();
        $this->uploadfolder = App::getConfig('uploads').'transaudio';
        $this->rawfolder = App::getConfig('uploads').'transaudio'.DIRECTORY_SEPARATOR.'quranful';
    }
    public function prepuploadfolder($sub=false){
        if($sub !== false && $sub != ''){
            $this->newfold = $this->uploadfolder.'/'.$sub;
        }
        else{
            $this->newfold = $this->uploadfolder.'/temp';
        }
	    if(!file_exists($this->newfold)){
            $dir = mkdir($this->newfold,0777);
            if(!$dir){
                echo $this->newfold;
                return false;
            }
        }
        return $this->newfold;
	}
    public function pageInit($data,$view='plain'){
        $counttes=0;
        foreach (scandir($this->rawfolder) as $item) {
            if ($item == '.' || $item == '..') continue;
            
            $itemx = explode('-',$item);
            $itemfold = intval($itemx[0]);
            $versenum = intval($itemx[1]);
            
            if($versenum==0){
                continue;
            }
            $newfile = $this->uploadfolder.DIRECTORY_SEPARATOR.$itemfold.DIRECTORY_SEPARATOR.$versenum.'.mp3';
            
            copy($this->rawfolder.DIRECTORY_SEPARATOR.$item,$newfile);
        }
        return $view;
    }
}
	

?>