-- phpMyAdmin SQL Dump
-- version 4.4.3
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 24, 2018 at 05:06 PM
-- Server version: 10.2.9-MariaDB-10.2.9+maria~xenial-log
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pxpedia`
--

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` ( `type`, `app`, `name`, `value`) VALUES
('globalpage', 13, 'dbsetting', '{"dbhost":"localhost","dbuser":"root","dbpasswd":"catormouse","dbname":"ahundredand14"}'),
('globalpage', 13, 'headsrc', '{"one14_quran":"one14\\/default\\/styles\\/quran.css","one14_fontface":"one14\\/default\\/styles\\/fontface.css","one14_favicon":"one14\\/default\\/styles\\/images\\/favicon.ico"}'),
('globalpage', 13, 'footsrc', '{"jquery_jquery-1":"jquery\\/jquery-1.9.1.min.js","jqueryui":"jquery\\/jquery-ui-1.10.3.custom.min.js","one14_largeappmin":"one14\\/largeapp.min.js"}'),
('globalpage', 13, 'keywords', 'keywords');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
